# Scengai

Scengai (Scenario-Guided Control Engineering Algorithms with AI) is a python library for robust design of control systems.

Scengai treats the model as a black-box and uses third party optimization solvers to compute optimized control parameters.

Scengai uses [PEtab](https://petab.readthedocs.io/en/latest/) for specifying the optimization problem and providing all the needed information.

The black-box solver currently supported by Scengai are:

- [NOMAD](https://www.gerad.ca/nomad/),
- [PySwarms](https://pyswarms.readthedocs.io/en/latest/),
- [SciPy Optimize](https://docs.scipy.org/doc/scipy/reference/optimize.html).

### Who do I talk to? ###

* Marco Esposito (author) - esposito@di.uniroma1.it
* Leonardo Picchiami (author) - picchiami@di.uniroma1.it

### Citing
M. Esposito, A. Leva, T. Mancini, L. Picchiami and E. Tronci, 
"Simulation-Based Design of Industry-Size Control Systems With Formal Quality Guarantees," 
in IEEE Transactions on Industrial Informatics, doi: 10.1109/TII.2025.3528556. (To appear)

BibTeX
```@article{esposito-etal:control-design:tii:2025,
  author={Esposito, Marco and Leva, Alberto and Mancini, Toni and Picchiami, Leonardo and Tronci, Enrico},
  journal={IEEE Transactions on Industrial Informatics}, 
  title={Simulation-Based Design of Industry-Size Control Systems With Formal Quality Guarantees}, 
  year={2025},
  pages={1-9},
  doi={10.1109/TII.2025.3528556}}
```


Copyright (C) 2020-2025 Sapienza University of Rome, Marco Esposito, Leonardo Picchiami.

Distributed under GNU General Public License v3.
