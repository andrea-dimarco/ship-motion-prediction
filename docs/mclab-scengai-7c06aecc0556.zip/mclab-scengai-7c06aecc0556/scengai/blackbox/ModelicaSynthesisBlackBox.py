from apricopt.simulation.SimulationEngine import SimulationEngine
from apricopt.solving.blackbox.BlackBox import BlackBox
from apricopt.simulation.executable.Modelica.ModelicaExecutableEngine import ModelicaExecutableEngine

from scengai.utils.ExecTimer import ExecTimer
from scengai.model.SynthesisModel import SynthesisModel
from scengai.utils.StatsOnlineAlgorithms import StatsOnlineAlgorithms

import numpy as np
import json, os

from multiprocessing import Queue

from typing import List, Dict, Optional, Tuple, Type


class ModelicaSynthesisBlackBox(BlackBox):

    def __init__(self, sim_engine_class: Type,
                 n_scenario_constraints: int,
                 task_request_queue: Queue,
                 task_response_queue: Queue,
                 synthesis_model: SynthesisModel,
                 is_simulations_dump_policy: bool,
                 worker_cwd: Optional[str] = None):

        # For now, we fix the only allowed SimulationEngine class
        assert sim_engine_class == ModelicaExecutableEngine
        #assert sim_engine_class == ModelicaExecutableEngineWithFiles
        self.sim_engine_class: Type = sim_engine_class
        self.sim_engine: SimulationEngine = synthesis_model.sim_engine #sim_engine_class()
        #self.uncertain_parameters_space: Dict[str, Parameter] = {
        #    param.id: param for param in uncertain_parameters_space
        #}

        self.horizon = 0 #horizon
        self.synthesis_model = synthesis_model

        self.constraints_cumulator = float("Inf")
        self.optimal_result = dict()
        self.optimal_control_parameters = dict()
        self.optimal_log_observables = dict()
        self.n_bb_evals = 0
        self.optimal_point_bb_eval = 0
        self.is_feasible = False
        self.number_of_simulations = 0

        # Queue data when optimization fails
        #self.queue_data = queue_data

        # number of scenario constraints
        self.n_scenario_constraints = n_scenario_constraints

        self.__parameters_ids, self.__parameters_lower_bounds, self.__parameters_upper_bounds, \
            self.__initial_values, self.__granularity = self._cache_parameters_info()

        self.__extreme_constraints_ids, self.__progressive_constraints_ids = self._cache_constraints_info()

        self.__x0_isempty: bool = False
        self.__granularity_required: bool = True

        # log_observables
        self.log_observables = synthesis_model.log_observables

        # Alternative simulation current working directory
        self.worker_cwd = worker_cwd

        # Scenarios simulator utilities #pool
        #self.simulator_pool = simulator_pool
        self.task_request_queue = task_request_queue
        self.task_response_queue = task_response_queue

        # Black-box timer
        self.bb_timer = ExecTimer()
        self.cumulative_bb_eval_exec_time = 0
        self.new_incumbent_timer = ExecTimer()
        self.cumulative_new_incumbent_exec_time = 0
        self.cumulative_exec_time = 0

        # Simulations stats
        self.sim_stats_online_algorithms = StatsOnlineAlgorithms()
        self.objective_stats_online_algorithms = StatsOnlineAlgorithms()

        # Storage for simulations to be saved
        self.is_simulations_dump_policy = is_simulations_dump_policy
        self.simulation_storage_for_dump = dict()


        # ~ End init


    def reset(self):
        self.constraints_cumulator = float("Inf")
        self.optimal_result = dict()
        self.optimal_control_parameters = dict()
        self.optimal_log_observables = dict()
        self.n_bb_evals = 0
        self.optimal_point_bb_eval = 0
        self.is_feasible = False
        self.number_of_simulations = 0

        self.cumulative_exec_time = 0
        self.cumulative_bb_eval_exec_time = 0
        self.cumulative_new_incumbent_exec_time = 0
        self.sim_stats_online_algorithms.reset_algorithm()
        self.objective_stats_online_algorithms.reset_algorithm()

        self.simulation_storage_for_dump = dict()

        self.__parameters_ids, self.__parameters_lower_bounds, self.__parameters_upper_bounds, \
            self.__initial_values, self.__granularity = self._cache_parameters_info()

        self.__extreme_constraints_ids, self.__progressive_constraints_ids = self._cache_constraints_info()

    def set_n_scenario_constraints(self, n_scenario_constraints: int) -> None:
        self.n_scenario_constraints = n_scenario_constraints

    def evaluate(self, control_parameters: Dict[str, float], check_input=False) -> Dict[str, float]:
        # Log observables values reload

        log_observables_values = {log_obs.id: {'min': float('Inf'), 'max': 0, 'sum': 0} for log_obs in
                                  self.log_observables}

        self.sim_stats_online_algorithms.reset_algorithm()

        #
        self.bb_timer.start()
        self.n_bb_evals += 1
        if self.n_bb_evals > 1:
            new_incumbent_elapsed_time = self.new_incumbent_timer.stop()
        else:
            new_incumbent_elapsed_time = 0

        self.cumulative_new_incumbent_exec_time += new_incumbent_elapsed_time
        self.simulation_storage_for_dump[f'bb_eval_{self.n_bb_evals}'] = dict()
        print(f"\nBlack-box evaluation {self.n_bb_evals}", flush=True)
        print(f"Evaluating control: {control_parameters}", flush=True)
        #print(f"Elapsed time by NOMAD to provide a new incumbent solution: {new_incumbent_elapsed_time} sec", flush=True)
        #print(f"Cumulative elapsed time to provide a new incumbent solution: "
        #f"{self.cumulative_new_incumbent_exec_time} sec", flush=True)

        # Normalizing control parameters for the system
        control = self.synthesis_model.get_normalized_params_values(control_parameters)

        # Set control_parameters
        self.synthesis_model.set_params(control)

        # Check control parameter admissibility
        # Fast constraints
        fast_constraints_values: Dict[
            str, float] = self.synthesis_model.evaluate_control_admissibility_fast_constraints(control)

        # If at least one fast constraint is violated, do not simulate the control, but return the result
        result = dict(fast_constraints_values)
        for constraint_value in fast_constraints_values.values():
            if constraint_value > 0:
                self.new_incumbent_timer.start()
                result[self.get_objective_id()] = self.get_objective_upper_bound() * 10000
                elapsed_time = self.bb_timer.stop()
                self.cumulative_exec_time += elapsed_time + new_incumbent_elapsed_time
                #print(f"Cumulative elapsed time for the optimisation: {self.cumulative_exec_time:.4f} sec", flush=True)
                for constraint in self.synthesis_model.constraints:
                    result[constraint.id] = constraint.upper_bound

                for scenario_obs in self.synthesis_model.scenario_observables:
                    for i in range(self.n_scenario_constraints):
                        result[f'{scenario_obs.id}_{i}'] = scenario_obs.upper_bound
                return result

        # Simulate control to evaluate the objective value and check whether it is admissible if there are constraints
        # Evaluate the objective value

        if len(self.synthesis_model.constraints) > 0:
            try:
                trajectory: Dict[str, List[float]] = self.sim_engine.simulate_trajectory(self.synthesis_model,
                                                                                         self.horizon)
                sim_out = True
            except:
                trajectory = dict()
                sim_out = False

            self.number_of_simulations += 1
            if not sim_out:
                self.new_incumbent_timer.start()
                result[self.get_objective_id()] = self.get_objective_upper_bound() * 10000
                elapsed_time = self.bb_timer.stop()
                self.cumulative_exec_time += elapsed_time + new_incumbent_elapsed_time
                # print(f"Cumulative elapsed time for the optimisation: {self.cumulative_exec_time:.4f} sec", flush=True)

                for constraint in self.synthesis_model.constraints:
                    result[constraint.id] = constraint.upper_bound

                for scenario_obs in self.synthesis_model.scenario_observables:
                    for i in range(self.n_scenario_constraints):
                        result[f'{scenario_obs.id}_{i}'] = scenario_obs.upper_bound

            constraints_values = self.synthesis_model.evaluate_control_admissibility_constraints(trajectory)
            result = dict(constraints_values, **result)
            for constraint_value in constraints_values.values():
                if constraint_value > 0:
                    self.new_incumbent_timer.start()
                    elapsed_time = self.bb_timer.stop()
                    self.cumulative_exec_time += elapsed_time + new_incumbent_elapsed_time
                    #print(f"Cumulative elapsed time for the optimisation: {self.cumulative_exec_time:.4f} sec",
                    #      flush=True)

                    for scenario_obs in self.synthesis_model.scenario_observables:
                        for i in range(self.n_scenario_constraints):
                            result[f'{scenario_obs.id}_{i}'] = scenario_obs.upper_bound
                    result[self.get_objective_id()] = self.get_objective_upper_bound()*10000
                    return result

        #print("Simulating scenarios with the candidate control parameters...", flush=True)
        self.task_request_queue.put((control, 'design'))
        sim_results = self.task_response_queue.get(block=True)
        self.number_of_simulations += self.n_scenario_constraints
        scenario_constraints = dict()
        n_violated_constraints = dict()
        constraints_penalty_comulator = dict()
        for scen_obs in self.synthesis_model.scenario_observables:
            n_violated_constraints[scen_obs.id] = 0
            constraints_penalty_comulator[scen_obs.id] = 0

        constraints_cumulator = 0
        conditions = []
        # print("\nDEBUG: scenario constraints values \n")
        for index, data in sim_results.items():
            self.__update_log_observables(log_observables_values, data[2])
            self.__update_simulation_time_stats(data[3])

            if self.is_simulations_dump_policy: self.__store_simulations(index, data)
            for scen_obs in self.synthesis_model.scenario_observables:
                scenario_constraints[f'{scen_obs.id}_{index}'] = data[0][scen_obs.id]
                constraints_cumulator += max(0, data[0][scen_obs.id]) #/ scen_obs.goodness_threshold
                constraints_penalty_comulator[scen_obs.id] += max(0, data[0][scen_obs.id])
                constraint_eval = data[0][scen_obs.id] <= 0
                n_violated_constraints[scen_obs.id] += 0 if constraint_eval else 1
                conditions.append(constraint_eval)
                # print(f"\t{index} - {scen_obs.id}: {data[0][scen_obs.id]}")
        # print("\nEND DEBUG\n\n")


        result = dict(scenario_constraints, **result)
        elapsed_time = self.bb_timer.stop()
        self.cumulative_bb_eval_exec_time += elapsed_time
        self.cumulative_exec_time += elapsed_time + new_incumbent_elapsed_time
        print(f"Black-box evaluation elapsed time: {elapsed_time:.4f} sec", flush=True)
        #print(f"Simulation time statistics for black-box evaluation:", flush=True)
        #print(f"\tAverage simulation time: {self.sim_stats_online_algorithms.get_sample_mean()}", flush=True)
        #print(f"\tVariance of average simulation time: {self.sim_stats_online_algorithms.get_sample_variance()}",
        #      flush=True)

        #print(f"Cumulative elapsed time for black-box evaluations: {self.cumulative_bb_eval_exec_time:.4f} sec", flush= True)
        print(f"Cumulative elapsed time for the optimisation: {self.cumulative_exec_time:.4f} sec", flush=True)
        print("[BB LOG] Log Observables statistics:", flush=True)
        for log_observable in self.synthesis_model.log_observables:
            print(f"[BB LOG][MEAN]"
                  f"\t{log_observable.format_message(log_observables_values[log_observable.id]['sum'] / self.n_scenario_constraints)}",
                  flush=True)
            print(f"[BB LOG][MIN]"
                  f"\t{log_observable.format_message(log_observables_values[log_observable.id]['min'])}", flush=True)
            print(f"[BB LOG][MAX]"
                  f"\t{log_observable.format_message(log_observables_values[log_observable.id]['max'])}", flush=True)

        print(f"[BB LOG] Constraints evaluation", flush=True)
        for scen_obs in self.synthesis_model.scenario_observables:
            print(f"[BB LOG]    {scen_obs.id}: {n_violated_constraints[scen_obs.id]} violated constraints.", flush=True)
            print(f"[BB LOG]    {scen_obs.id}: {constraints_penalty_comulator[scen_obs.id]} penalty comulation.", flush=True)

        result[self.get_objective_id()] = 0     # TODO change
        is_feasible = all(conditions)

        if is_feasible:
            self.constraints_cumulator = constraints_cumulator
            self.optimal_result = result
            self.optimal_control_parameters = control
            self.optimal_log_observables = log_observables_values
            self.optimal_point_bb_eval = self.n_bb_evals
            self.is_feasible = is_feasible

        self.new_incumbent_timer.start()

        return result

    def get_number_of_simulations(self) -> int:
        return self.number_of_simulations

    def __update_log_observables(self, log_observables_values, log_observables_data):
        for log_obs_id, val in log_observables_data.items():
            if val < log_observables_values[log_obs_id]['min']:
                log_observables_values[log_obs_id]['min'] = val

            if val > log_observables_values[log_obs_id]['max']:
                log_observables_values[log_obs_id]['max'] = val

            log_observables_values[log_obs_id]['sum'] += val

    def __update_simulation_time_stats(self, sim_time_data: float):
        self.sim_stats_online_algorithms.increase_counter()
        self.sim_stats_online_algorithms.update_sample_mean(sim_time_data)
        self.sim_stats_online_algorithms.update_sample_variance(sim_time_data)

    def __store_simulations(self, sim_index: int, simulation_data: dict):
        self.simulation_storage_for_dump[f'bb_eval_{self.n_bb_evals}'][str(sim_index)] = dict()
        self.simulation_storage_for_dump[f'bb_eval_{self.n_bb_evals}'][str(sim_index)]['simulation_index'] = sim_index
        self.simulation_storage_for_dump[f'bb_eval_{self.n_bb_evals}'][str(sim_index)]['simulation_data'] = simulation_data[0]
        self.simulation_storage_for_dump[f'bb_eval_{self.n_bb_evals}'][str(sim_index)]['simulation_time'] = simulation_data[3]

    def dump_simulations(self, sim_output_path: str, algo_iteration: int):
        if not os.path.exists(sim_output_path):
            raise ValueError("A version of this JSON path must be exist")

        with open(sim_output_path, 'r') as f:
            data_to_store = json.load(f)

        find_solution_storage = data_to_store[f'algorithm_epoch_{algo_iteration}']['find_solution']
        find_solution_storage = dict(self.simulation_storage_for_dump, **find_solution_storage)
        data_to_store[f'algorithm_epoch_{algo_iteration}']['find_solution'] = find_solution_storage
        with open(sim_output_path, 'w') as f:
            json.dump(data_to_store, f, indent=4)

        del find_solution_storage, data_to_store, self.simulation_storage_for_dump
        self.simulation_storage_for_dump = dict()

    def set_optimization_parameters_initial_values(self, control: Dict[str, float]) -> None:
        for param_id, param_value in control.items():
            self.__initial_values[param_id] = param_value

    def optimization_parameters_initial_values_are_empty(self) -> bool:
        return self.__x0_isempty

    def set_optimization_parameters_initial_values_are_empty(self, are_empty: bool) -> None:
        self.__x0_isempty = are_empty

    def granularity_is_required(self) -> bool:
        return self.__granularity_required

    def set_granularity_is_required(self, is_required: bool) -> None:
        self.__granularity_required = is_required

    @staticmethod
    def to_hms(seconds):
        m, s = divmod(seconds, 60)
        h, m = divmod(m, 60)
        return '{} hours {:0>2} minutes {:0>2.2f} seconds'.format(h, m, s)

    def get_optimization_parameters_number(self) -> int:
        return len(self.synthesis_model.parameters)

    def get_optimization_parameters_ids(self) -> List[str]:
        return self.__parameters_ids

    def _cache_parameters_info(self) -> Tuple[List[str], Dict[str, float], Dict[str, float], Dict[str, float],
                                              Dict[str, float]]:
        lower_bounds: Dict[str, float] = {}
        upper_bounds: Dict[str, float] = {}
        initial_values: Dict[str, float] = {}
        granularity: Dict[str, float] = {}

        params_ids: List[str] = [p_id for p_id in self.synthesis_model.parameters]
        params_ids.sort()

        for parameter_id, parameter in self.synthesis_model.parameters.items():
            lower_bounds[parameter_id] = parameter.lower_bound
            upper_bounds[parameter_id] = parameter.upper_bound
            initial_values[parameter_id] = parameter.nominal_value
            granularity[parameter_id] = parameter.granularity

        return params_ids, lower_bounds, upper_bounds, initial_values, granularity

    def get_optimization_parameter_lower_bound(self, param_id) -> float:
        return self.__parameters_lower_bounds[param_id]

    def get_optimization_parameter_upper_bound(self, param_id) -> float:
        return self.__parameters_upper_bounds[param_id]

    def get_optimization_parameter_initial_value(self, param_id) -> float:
        return self.__initial_values[param_id]

    def get_optimization_parameter_granularity(self, param_id) -> float:
        return self.__granularity[param_id]

    def get_extreme_barrier_constraints_number(self) -> int:
        # TODO: choose between extreme barrier constraints and progressive barrier constraints
        return len(self.synthesis_model.fast_constraints) + len(self.synthesis_model.constraints)# + \

    def get_progressive_barrier_constraints_number(self) -> int:
        return len(self.synthesis_model.scenario_observables)*self.n_scenario_constraints

    def _cache_constraints_info(self) -> Tuple[List[str], List[str]]:
        extreme_ids: List[str] = []
        progressive_ids: List[str] = []

        for treat_fast_cons in self.synthesis_model.fast_constraints:
            extreme_ids.append(treat_fast_cons.id)
        
        for treat_cons in self.synthesis_model.constraints:
            extreme_ids.append(treat_cons.id)

        for scenario_obs in self.synthesis_model.scenario_observables:
            for i in range(self.n_scenario_constraints):
                progressive_ids.append(f'{scenario_obs.id}_{i}')

        #extreme_ids.append('feasibility_constraint')

        extreme_ids.sort()
        progressive_ids.sort()
        return extreme_ids, progressive_ids# []

    def get_extreme_barrier_constraints_ids(self) -> List[str]:
        return self.__extreme_constraints_ids

    def get_progressive_barrier_constraints_ids(self) -> List[str]:
        return self.__progressive_constraints_ids

    def get_objective_id(self) -> str:
        return self.synthesis_model.objective.id

    def get_objective_upper_bound(self) -> float:
        return self.synthesis_model.objective.upper_bound

    @staticmethod
    def get_raisable_exception_type():
        return Exception

    def finalize(self):
        pass

    def evaluate_np_array(self, parameters: np.array, check_input=False) -> Dict[str, float]:
        raise NotImplementedError

    def evaluate_objective_np_array(self, parameters: np.array, check_input=False) -> float:
        raise NotImplementedError

    def is_input_valid(self, parameters: Dict[str, float]) -> bool:
        raise NotImplementedError

    def get_optimization_parameters_lower_bounds_nparray(self) -> np.array:
        raise NotImplementedError

    def get_optimization_parameters_upper_bounds_nparray(self) -> np.array:
        raise NotImplementedError
