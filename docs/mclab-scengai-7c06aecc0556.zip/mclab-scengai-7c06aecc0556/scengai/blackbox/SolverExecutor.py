import concurrent
import random
from concurrent.futures import ProcessPoolExecutor, as_completed
from concurrent.futures import ProcessPoolExecutor

import numpy as np

from scengai.blackbox.ModelicaSynthesisBlackBox import ModelicaSynthesisBlackBox
from apricopt.solving.blackbox.BlackBoxSolver import BlackBoxSolver
from scengai.blackbox.ModelicaSBTBlackBox import ModelicaSBTBlackBox
from multiprocessing import Process, Queue
from typing import Dict, Any, Tuple, List, Union

def _set_all_seeds(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)

def _set_nomad_seed(solver_parameters: dict, sbt_nomad_seed: int) -> dict:
    solver_parameters = solver_parameters.copy()
    solver_parameters["solver_params"] = [
        p for p in solver_parameters.get("solver_params", [])
        if not p.startswith("SEED")
    ]
    solver_parameters["solver_params"].append(f"SEED {sbt_nomad_seed}")
    return solver_parameters

def _run_nomad_subprocess_seeded(solver: BlackBoxSolver, black_box: ModelicaSynthesisBlackBox|ModelicaSBTBlackBox, solver_parameters: Dict[str, Any],
                                 queue: Queue, additional_data: Tuple[bool, str, int], sbt_nomad_seed: int) -> None:
    if sbt_nomad_seed is not None:
        _set_all_seeds(sbt_nomad_seed)
    print("DEBUG from _run_nomad_subprocess_seeded: " + str(solver_parameters['solver_params']))

    run_nomad_subprocess(solver, black_box, solver_parameters, queue, additional_data)


def run_nomad_subprocess(solver: BlackBoxSolver, black_box: ModelicaSynthesisBlackBox|ModelicaSBTBlackBox, solver_parameters: Dict[str, Any],
                         queue: Queue, additional_data: Tuple[bool, str, int]) -> None:
    opt_result = solver.solve(black_box, solver_parameters)
    (is_simulations_dump_policy, simulations_dump_path, iter_cnt) = additional_data
    if is_simulations_dump_policy: black_box.dump_simulations(simulations_dump_path, iter_cnt)
    result_from_bb = store_blackbox_results(black_box)
    if isinstance(black_box, ModelicaSBTBlackBox):
        queue.put((opt_result, result_from_bb, False, black_box.get_number_of_simulations(), black_box.cache))
    else:
        queue.put((opt_result, result_from_bb, False, black_box.get_number_of_simulations()))


def store_blackbox_results(black_box:ModelicaSynthesisBlackBox|ModelicaSBTBlackBox):
    if isinstance(black_box, ModelicaSynthesisBlackBox):
        n_bb_evals = black_box.n_bb_evals
        optimal_control_parameters = black_box.optimal_control_parameters
        constraints_values_cumulator = black_box.constraints_cumulator
        optimal_log_observables = black_box.optimal_log_observables
        optimal_point_bb_eval = black_box.optimal_point_bb_eval
        optimal_control_result = black_box.optimal_result
        is_result_feasible = black_box.is_feasible

        result_from_bb = {"optimal_control_parameters": optimal_control_parameters,
                          "constraints_values_cumulator": constraints_values_cumulator,
                          "optimal_control_point_bb_eval": optimal_point_bb_eval,
                          "optimal_control_result": optimal_control_result,
                          "optimal_control_log_observables": optimal_log_observables,
                          "optimization_bb_evals": n_bb_evals,
                          "if_feasible_result": is_result_feasible}
    else:
        result_from_bb = dict()

    return result_from_bb


class SolverExecutor:

    @staticmethod
    def find_solution(solver: BlackBoxSolver,
                      black_box: ModelicaSynthesisBlackBox|ModelicaSBTBlackBox,
                      solver_parameters: Dict[str, Any],
                      additional_data: Tuple[bool, str, int],
                      timeout: int,
                      sbt_worker_seed: int = None,
                      sbt_nomad_seed: int = None):
        # _set_all_seeds(sbt_worker_seed)
        # print("\n\nSBT_WORKER_SEEDD: ", sbt_worker_seed)

        # if sbt_nomad_seed is not None and sbt_worker_seed is not None:
        #     solver_parameters['solver_params'] = [
        #         f"SEED {sbt_nomad_seed}" if p.startswith("SEED ") else p
        #         for p in solver_parameters['solver_params']
        #     ]

        #ANNUA
        _set_all_seeds(sbt_worker_seed)

        queue = Queue()
        p = Process(target=_run_nomad_subprocess_seeded, args=(solver, black_box, solver_parameters, queue, additional_data, sbt_nomad_seed))
        p.daemon = False
        p.start()

        try:
            opt_result = queue.get(block=True, timeout=timeout)
        except:
            opt_result = (dict(), dict(), True, black_box.get_number_of_simulations())
            if p.is_alive():
                p.kill()

        p.join()
        return opt_result


    def call_find_solution(args):
        return SolverExecutor.find_solution(*args)

    @staticmethod
    def find_solutions(solver: BlackBoxSolver,
            black_boxes: list[ModelicaSBTBlackBox],
            solver_parameters: Dict[str, Any],
            additional_data: Tuple[bool, str, int],
            timeout: int):

        # datas = [(solver, bb, solver_parameters, additional_data, timeout) for bb in black_boxes]

        datas = []

        sbt_worker_seed = random.randint(0, 2**31 - 1)
        for bb in black_boxes:
            sbt_nomad_seed  = random.randint(0, 2**31 - 1)
            solver_params_with_seed = _set_nomad_seed(solver_parameters, sbt_nomad_seed)
            datas.append((solver, bb, solver_params_with_seed, additional_data, timeout, sbt_worker_seed, sbt_nomad_seed))

        with concurrent.futures.ProcessPoolExecutor() as executor:
            result_from_bb = list(executor.map(SolverExecutor.call_find_solution, datas))
        return result_from_bb




