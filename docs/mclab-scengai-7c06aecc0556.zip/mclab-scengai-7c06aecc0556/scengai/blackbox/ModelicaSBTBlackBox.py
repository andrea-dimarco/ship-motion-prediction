import hashlib
import json

from apricopt.simulation.SimulationEngine import SimulationEngine
from apricopt.solving.blackbox.BlackBox import BlackBox
from apricopt.simulation.executable.Modelica.ModelicaExecutableEngine import ModelicaExecutableEngine

from scengai.model.SBTModel import SBTModel
from scengai.utils.ExecTimer import ExecTimer
from scengai.utils.StatsOnlineAlgorithms import StatsOnlineAlgorithms

import numpy as np


from typing import List, Dict, Tuple, Type, Any


class ModelicaSBTBlackBox(BlackBox):
    sbt_model: SBTModel
    optimal_scenario_parameters: dict[str, float]
    cache: dict[str, dict[str, float]]

    def __init__(self, sim_engine_class: Type,
                 sbt_model: SBTModel,

                 worker_cwd: str|None= None):

        assert sim_engine_class == ModelicaExecutableEngine
        self.sim_engine_class: Type = sim_engine_class
        self.sim_engine: SimulationEngine = sbt_model.sim_engine

        self.reset_cache()

        self.horizon = 0  # horizon
        self.sbt_model = sbt_model

        self.optimal_result = dict()
        self.optimal_scenario_parameters = dict()
        self.optimal_log_observables = dict()
        self.n_bb_evals = 0
        self.optimal_point_bb_eval = 0
        self.is_feasible = False
        self.number_of_simulations = 0

        self.__parameters_ids, self.__parameters_lower_bounds, self.__parameters_upper_bounds, \
            self.__initial_values, self.__granularity = self._cache_parameters_info()

        self.__x0_isempty: bool = False
        self.__granularity_required: bool = True


        # Alternative simulation current working directory
        self.worker_cwd = worker_cwd

        # Black-box timer
        self.bb_timer = ExecTimer()
        self.cumulative_bb_eval_exec_time = 0
        self.cumulative_exec_time = 0

        # Simulations stats
        self.sim_stats_online_algorithms = StatsOnlineAlgorithms()
        self.objective_stats_online_algorithms = StatsOnlineAlgorithms()

        # Storage for simulations to be saved
        self.simulation_storage_for_dump = dict()
        self.last_log_observables = dict()

        # ~ End init

    def reset(self):
        self.optimal_result = dict()
        self.optimal_scenario_parameters = dict()
        self.optimal_log_observables = dict()
        self.n_bb_evals = 0
        self.optimal_point_bb_eval = 0
        self.is_feasible = False
        self.number_of_simulations = 0

        self.cumulative_exec_time = 0
        self.cumulative_bb_eval_exec_time = 0
        self.sim_stats_online_algorithms.reset_algorithm()
        self.objective_stats_online_algorithms.reset_algorithm()

        self.simulation_storage_for_dump = dict()

        self.__parameters_ids, self.__parameters_lower_bounds, self.__parameters_upper_bounds, \
            self.__initial_values, self.__granularity = self._cache_parameters_info()



    def evaluate(self, scenario_parameters: Dict[str, float], check_input=False) -> Dict[str, float]:
        self.sim_stats_online_algorithms.reset_algorithm()

        #
        self.bb_timer.start()
        self.n_bb_evals += 1


        print(f"\nBlack-box evaluation {self.n_bb_evals}", flush=True)
        print(f"Evaluating scenario: {scenario_parameters}", flush=True)


        # Normalizing control parameters for the system
        scenario: dict[str, float] = self.sbt_model.get_normalized_params_values(scenario_parameters)

        # Set control_parameters
        self.sbt_model.set_params(scenario)

        result: dict[str, float] = dict()
        # No fast constraints for the scenario (for now!)

        # Simulate control to evaluate the objective value and check whether it is admissible if there are constraints
        # Evaluate the objective value

        try:
            trajectory: Dict[str, List[float]] = self.sim_engine.simulate_trajectory(self.sbt_model,
                                                                                     self.horizon)


            sim_out = True
        except Exception as e:
            trajectory = dict()
            sim_out = False
            print(e)

        last_log_observables_data: Dict[str, float] = {obs.id: obs.value(trajectory)
                                                  for obs in self.sbt_model.log_observables}

        self.number_of_simulations += 1
        if not sim_out:
            result[self.get_objective_id()] = self.get_objective_upper_bound() * 10000
            elapsed_time = self.bb_timer.stop()
            self.cumulative_exec_time += elapsed_time
            print(f"Cumulative elapsed time for the optimisation: {self.cumulative_exec_time:.4f} sec", flush=True)

            for constraint in self.sbt_model.constraints:
                result[constraint.id] = constraint.upper_bound

        # constraints_values = self.sbt_model.evaluate_constraints(trajectory) # contains also the objective value
        constraints_values = self.normalize_constraints_values(self.sbt_model.evaluate_constraints(trajectory)) # contains also the objective value
        print("DEBUG from ModelicaSBTBlackBox. constraints:", constraints_values)
        print("DEBUG from ModelicaSBTBlackBox. constraints:", self.normalize_constraints_values(constraints_values))


        kpi_violations: dict[str, float] = {}

        # FIXME Qui abbiamo scelto il valore del KPI minimo, cioè più violato. Si può fare di meglio (?)
        min_kpi = float("Inf")
        positive_kpis: set[str] = set()
        for constraint_id, constraint_value in constraints_values.items():
            # constr_threshold = self.sbt_model.get_scenario_kpi_goodness_threshold(constraint_id)
            constr_threshold = self.normalize_constr_threshold(self.sbt_model.get_scenario_kpi_goodness_threshold(constraint_id), constraint_id)
            value = constr_threshold - constraint_value  # il vincolo è KPI <= threshold
            kpi_violations[constraint_id] = value
            if value > 0:
                positive_kpis.add(constraint_id)
            if value < min_kpi:
                min_kpi = value

        print(f"Scenario observable values: {constraints_values}", flush=True)
        print(f"KPI violations (negative is violation): {kpi_violations}", flush=True)

        print(f"\nMinimum of KPIs: {min_kpi:.4f}\n", flush=True)
        if min_kpi < 0:
            # At least one threshold is violated

            # We found a violating scenario.
            # In order to let NOMAD know it has to stop, we have to set all constraints values to negative values,
            #   by flipping the sign of the positive ones.
            # Do not worry: we have stored in 'positive_kpis' the ids of constraints that are not violated,
            #   so that we can reconstruct the actual kpi violations later.

            for constraint_id, kpi_violation in kpi_violations.items():
                if kpi_violation > 0:
                    kpi_violations[constraint_id] = -kpi_violation


            result = dict(**kpi_violations, **result)

            self.optimal_control_parameters = scenario_parameters
            self.constraints_cumulator = min_kpi

            self.optimal_log_observables = {}
            self.optimal_point_bb_eval = 0
            self.optimal_control_result = 0
            self.is_result_feasible = True # non fa niente
        else:
            result = dict(**kpi_violations, **result)


        result["positive_kpis_ids"] = positive_kpis
        result[self.get_objective_id()] = min_kpi

        print("DEBUG from ModelicaSBTBlackBox. result:", result)





        elapsed_time = self.bb_timer.stop()
        self.cumulative_bb_eval_exec_time += elapsed_time
        self.cumulative_exec_time += elapsed_time
        print(f"Black-box evaluation elapsed time: {elapsed_time:.4f} sec", flush=True)
        print(f"Simulation time statistics for black-box evaluation:", flush=True)
        print(f"\tAverage simulation time: {self.sim_stats_online_algorithms.get_sample_mean()}", flush=True)
        # print(f"\tVariance of average simulation time: {self.sim_stats_online_algorithms.get_sample_variance()}",
        #      flush=True)

        print(f"Cumulative elapsed time for black-box evaluations: {self.cumulative_bb_eval_exec_time:.4f} sec",
              flush=True)
        # print(f"Cumulative elapsed time for the optimisation: {self.cumulative_exec_time:.4f} sec", flush=True)


        '''
        Se serve controllare (o memorizzare) se il punto era feasible o meno, fare più o meno come di seguito
        conditions: list[bool] = [constraint_value <= 0 for name, constraint_value in constraints_values.items()
                                  if name != self.get_objective_id()]
        is_feasible = all(conditions)

        if is_feasible:
            self.optimal_result = result
            self.optimal_control_parameters = scenario
            self.optimal_point_bb_eval = self.n_bb_evals
            self.is_feasible = is_feasible'''

        h = hashlib.new('sha256')
        h.update(json.dumps(scenario_parameters).encode())
        to_store: dict[str, float | dict[str, float]] = dict(**result)
        to_store["scenario"] = scenario_parameters
        self.cache[h.hexdigest()] = to_store

        result['log_observables_data'] = last_log_observables_data
        result['simulation_time'] = elapsed_time

        return result

    @staticmethod
    def normalize_constraints_values(constraints_values: dict[str, float]) -> dict[str, float]:
        constraints_values_normalized = dict()
        constraints_values_normalized["avg_PCurr_t_lower_b"] = (constraints_values["avg_PCurr_t_lower_b"] - 200000)/(300000-200000)
        constraints_values_normalized["avg_THSret_min_absolute_violation_lower_b"] = (constraints_values["avg_THSret_min_absolute_violation_lower_b"])/(7.5)
        return constraints_values_normalized

    @staticmethod
    def normalize_constr_threshold(constr_threshold: float, constr_id: str) -> float:
        if constr_id == "avg_PCurr_t_lower_b":
            return (constr_threshold-200000) / (300000-200000)
        return constr_threshold/7.5


    def get_evaluated_point_result(self, scenario_params: dict[str, float]) -> dict[str, Any]:
        h = hashlib.new('sha256')
        h.update(json.dumps(scenario_params).encode())
        d = h.hexdigest()
        print("DEBUG from ModelicaSBTBlackBox  cache: " + json.dumps(self.cache))
        if d not in self.cache:
            raise ValueError(f"The scenario {scenario_params} has never been evaluated")
        return self.cache[d]

    def reset_cache(self):
        print("DEBUG: Resetting cache **************************************************************************    ")
        self.cache = {}

    def get_number_of_simulations(self) -> int:
        return self.number_of_simulations

    def set_optimization_parameters_initial_values(self, scenario: Dict[str, float]) -> None:
        for param_id, param_value in scenario.items():
            self.__initial_values[param_id] = param_value

    def optimization_parameters_initial_values_are_empty(self) -> bool:
        return self.__x0_isempty

    def set_optimization_parameters_initial_values_are_empty(self, are_empty: bool) -> None:
        self.__x0_isempty = are_empty

    def granularity_is_required(self) -> bool:
        return self.__granularity_required

    def set_granularity_is_required(self, is_required: bool) -> None:
        self.__granularity_required = is_required

    @staticmethod
    def to_hms(seconds):
        m, s = divmod(seconds, 60)
        h, m = divmod(m, 60)
        return '{} hours {:0>2} minutes {:0>2.2f} seconds'.format(h, m, s)

    def get_optimization_parameters_number(self) -> int:
        return len(self.sbt_model.parameters)

    def get_optimization_parameters_ids(self) -> List[str]:
        return self.__parameters_ids

    def _cache_parameters_info(self) -> Tuple[List[str], Dict[str, float], Dict[str, float], Dict[str, float],
    Dict[str, float]]:
        lower_bounds: Dict[str, float] = {}
        upper_bounds: Dict[str, float] = {}
        initial_values: Dict[str, float] = {}
        granularity: Dict[str, float] = {}

        params_ids: List[str] = [p_id for p_id in self.sbt_model.parameters]
        params_ids.sort()

        for parameter_id, parameter in self.sbt_model.parameters.items():
            lower_bounds[parameter_id] = parameter.lower_bound
            upper_bounds[parameter_id] = parameter.upper_bound
            initial_values[parameter_id] = parameter.nominal_value
            granularity[parameter_id] = parameter.granularity

        return params_ids, lower_bounds, upper_bounds, initial_values, granularity

    def get_optimization_parameter_lower_bound(self, param_id) -> float:
        return self.__parameters_lower_bounds[param_id]

    def get_optimization_parameter_upper_bound(self, param_id) -> float:
        return self.__parameters_upper_bounds[param_id]

    def get_optimization_parameter_initial_value(self, param_id) -> float:
        return self.__initial_values[param_id]

    def get_optimization_parameter_granularity(self, param_id) -> float:
        return self.__granularity[param_id]

    def get_extreme_barrier_constraints_number(self) -> int:
        return len(self.sbt_model.fast_constraints)

    def get_progressive_barrier_constraints_number(self) -> int:
        return len(self.sbt_model.constraints) # TODO check


    def get_extreme_barrier_constraints_ids(self) -> List[str]:
        return [p.id for p in self.sbt_model.fast_constraints]

    def get_progressive_barrier_constraints_ids(self) -> List[str]:
        return [p.id for p in self.sbt_model.constraints]

    def get_objective_id(self) -> str:
        # return self.sbt_model.objective.id
        return "sbt_objective"

    def get_objective_upper_bound(self) -> float:
        return self.sbt_model.objective.upper_bound

    @staticmethod
    def get_raisable_exception_type():
        return Exception

    def finalize(self):
        pass

    def evaluate_np_array(self, parameters: np.array, check_input=False) -> Dict[str, float]:
        raise NotImplementedError

    def evaluate_objective_np_array(self, parameters: np.array, check_input=False) -> float:
        raise NotImplementedError

    def is_input_valid(self, parameters: Dict[str, float]) -> bool:
        raise NotImplementedError

    def get_optimization_parameters_lower_bounds_nparray(self) -> np.array:
        raise NotImplementedError

    def get_optimization_parameters_upper_bounds_nparray(self) -> np.array:
        raise NotImplementedError


