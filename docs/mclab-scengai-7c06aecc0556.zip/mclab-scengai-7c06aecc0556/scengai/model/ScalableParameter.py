from apricopt.model.Parameter import Parameter

from pandas import DataFrame
from typing import Set


class ScalableParameter(Parameter):
    to_input_generator: bool

    def __init__(self, param_id: str, name: str, lower_bound: float = float("-inf"),
                 upper_bound: float = float("inf"), nominal_value: float = float("-inf"),
                 distribution: str = 'uniform', mu: float = 0, sigma: float = 0,
                 granularity: float = 0, optimize: bool = True,
                 multiplier: float = 1, offset: float = 0,
                 to_input_generator: bool = False):

        super(ScalableParameter, self).__init__(param_id, name, lower_bound, upper_bound, nominal_value,
                                                distribution, mu, sigma, granularity, optimize)

        self.multiplier = multiplier
        self.offset = offset
        self.to_input_generator = to_input_generator


def get_scalable_parameter_space(parameter_df: DataFrame) -> Set[ScalableParameter]:
    params: Set[ScalableParameter] = set()
    for param_id, data in parameter_df.iterrows():
        params.add(ScalableParameter(str(param_id), data.parameterName,
                             data.lowerBound, data.upperBound, data.nominalValue,
                             data.distribution, data.mu, data.sigma, data.granularity, data.estimate,
                                     data.multiplier, data.offset, data.toInputGenerator))
    return params