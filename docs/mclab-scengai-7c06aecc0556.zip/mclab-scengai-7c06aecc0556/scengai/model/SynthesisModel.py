import os
from typing import List, Set, Dict, Any
from apricopt.model.Model import Model
from apricopt.model.Observable import Observable
from apricopt.model.Parameter import Parameter

from scengai.model.ScalableParameter import ScalableParameter
from scengai.model.ScenarioObservable import ScenarioObservable
from scengai.sbt.InputGenerator import InputGenerator


class SynthesisModel(Model):

    input_generator: InputGenerator|None
    gen_input_full_filename: str|None
    parameters: Dict[str, ScalableParameter]

    def __init__(self, sim_engine, model_filename: str, abs_tol: float, rel_tol: float, time_step: float,
                 uncertain_parameters: set[ScalableParameter],
                 input_generator: InputGenerator|None=None,
                 gen_input_filename: str|None=None,
                 observed_outputs: List[str] = None,
                 observed_outputs_observable: List[Observable] = None,
                 **exec_info):
        super().__init__(sim_engine, model_filename, abs_tol, rel_tol, time_step, observed_outputs,
                         observed_outputs_observable, **exec_info)
    
        # observables in self.constraints represent control constraints
        # observables in self.fast_constraints represent control fast constraints (i.e., no requiring simulations)
        self.cached_ids: Set[str] = set()
        self.objective_formula = str()
        self.scenario_observables: Set[ScenarioObservable] = set()
        self.additional_parameters: Set[Parameter] = set()
        self.additional_params_values: Dict[str, Any] = dict() # FIXME cosa sono questi???
        self.uncertain_parameters: dict[str, ScalableParameter] = {p.id: p for p in uncertain_parameters}
        self.simulation_working_directory = exec_info["cwd"] # La directory in cui si trova il modello compilato e dove va scritto il file .mat della traiettoria da simulare
        if input_generator and gen_input_filename:
            self.set_input_generator(input_generator=input_generator, gen_input_filename=gen_input_filename)


    def set_input_generator(self, input_generator: InputGenerator|None, gen_input_filename: str|None):
        self.input_generator = input_generator
        #self.gen_input_full_filename = f"{self.simulation_working_directory}/{gen_input_filename}"
        if "/" in gen_input_filename: # FIX fa un po' schifo
            self.gen_input_full_filename = gen_input_filename
        else:
            self.gen_input_full_filename = f"{self.simulation_working_directory}/{gen_input_filename}"

    def get_observables_ids(self) -> Set[str]:
        """Return the identifiers of the model observables, as a set of strings."""
        if not self.cached_ids:
            self.cached_ids: Set[str] = set()
            if self.objective:
                self.cached_ids.add(self.objective.id)

            for constraint in self.constraints:
                self.cached_ids.add(constraint.id)

            for fast_constraint in self.fast_constraints:
                self.cached_ids.add(fast_constraint.id)
        return self.cached_ids

    def evaluate_control_admissibility_fast_constraints(self, params: Dict[str, float]) -> Dict[str, float]:
        return self.evaluate_fast_constraints(params)

    def evaluate_control_admissibility_constraints(self, trajectory) -> Dict[str, float]:
        return {c_id: v for c_id, v in self.evaluate_constraints(trajectory).items() if c_id != self.objective.id}

    def build_additional_params_values(self):
        self.additional_params_values = {param.id: param.nominal_value for param in self.additional_parameters}

    def get_additional_params_values(self) -> Dict[str, Any]:
        return self.additional_params_values

    def get_normalized_params_values(self, parameters: Dict[str, float]) -> Dict[str, float]:
        normalized_params_values: Dict[str, float] = dict()
        for param_id, val in parameters.items():
            multiplier = self.parameters[param_id].multiplier
            offset = self.parameters[param_id].offset
            normalized_params_values[param_id] = val * multiplier + offset

        return normalized_params_values

    '''def set_params(self, params_values: Dict[str, float]) -> None:
        for param_id, value in params_values.items():
            param_obj = self.parameters[param_id]
            multiplier = param_obj.multiplier
            offset = param_obj.offset
            if param_obj.distribution == "uniform":
                if value < param_obj.lower_bound*multiplier+offset or \
                        value > param_obj.upper_bound*multiplier+offset:
                    raise ValueError(f"The value {value} for parameter {param_obj.name} is out of bounds.")
        self.instance.set_parameters(params_values)
        self.initial_values = self.build_initial_values()'''

    def set_params(self, params_values: Dict[str, float]) -> None:
        params_to_set: dict[str, float] = {pid: params_values[pid]
                                           for pid in params_values if pid not in self.uncertain_parameters
                                           or not self.uncertain_parameters[pid].to_input_generator}

        params_to_input_generator: dict[str, float] = {pid: params_values[pid]
                                                       for pid in params_values if pid in self.uncertain_parameters
                                                       and self.uncertain_parameters[pid].to_input_generator}

        for param_id, value in params_to_set.items():
            if param_id in self.parameters:
                param_obj = self.parameters[param_id]
            elif param_id in self.uncertain_parameters:
                param_obj = self.uncertain_parameters[param_id]
            else:
                continue
            multiplier = param_obj.multiplier
            offset = param_obj.offset
            if param_obj.distribution == "uniform":
                if value < param_obj.lower_bound * multiplier + offset or \
                        value > param_obj.upper_bound * multiplier + offset:
                    raise ValueError(f"The value {value} for parameter {param_obj.name} is out of bounds.")
        params_to_set["fileName"] = f"\"{os.path.abspath(self.gen_input_full_filename)}\""
        self.instance.set_parameters(params_to_set)
        self.initial_values = self.build_initial_values()
        if params_to_input_generator:
            print(f"Params to input generator in SynthesisModel::set_params():  {params_to_input_generator}")
            print(self.gen_input_full_filename)
            self.input_generator.generate_to_file(params_to_input_generator, self.gen_input_full_filename)

    def set_fixed_params(self, params_values: Dict[str, float]) -> None:
        params_to_set: dict[str, float] = {pid: params_values[pid]
                                           for pid in params_values if pid not in self.uncertain_parameters
                                           or not self.uncertain_parameters[pid].to_input_generator}

        params_to_input_generator: dict[str, float] = {pid: params_values[pid]
                                                       for pid in params_values if pid in self.uncertain_parameters
                                                       and self.uncertain_parameters[pid].to_input_generator}

        self.instance.set_parameters(params_to_set)
        self.initial_values = self.build_initial_values()

        if params_to_input_generator:
            print(f"Params to input generator in SynthesisModel::set_fixed_params():  {params_to_input_generator}")
            print(self.gen_input_full_filename)
            self.input_generator.generate_to_file(params_to_input_generator, self.gen_input_full_filename)

    '''def get_param(self, param_id: str) -> ScalableParameter | None:
        return self.parameters[param_id] if param_id in self.parameters else None'''



