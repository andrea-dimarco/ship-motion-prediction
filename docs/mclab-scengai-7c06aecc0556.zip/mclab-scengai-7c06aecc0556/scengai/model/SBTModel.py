import os
from typing import List, Set, Dict
from apricopt.model.Model import Model
from apricopt.model.Observable import Observable
from apricopt.simulation.executable.Modelica.ModelicaExecutableEngine import ModelicaExecutableEngine

from scengai.model.ScalableParameter import ScalableParameter
from scengai.model.ScenarioObservable import ScenarioObservable
from scengai.sbt.InputGenerator import InputGenerator


class SBTModel(Model):
    # This class represents simulable models for Search-Based Testing of a given controller.
    # The parameters represent scenarios -- the controller is fixed

    sbt_objective: Observable
    parameters: Dict[str, ScalableParameter]
    input_generator: InputGenerator
    gen_input_full_filename: str
    constraints: set[ScenarioObservable]
    control_params: dict[str, float]


    def __init__(self, sim_engine: ModelicaExecutableEngine, model_filename: str, abs_tol: float, rel_tol: float, time_step: float,
                 sbt_objective: Observable,
                 input_generator: InputGenerator=None,
                 gen_input_filename: str=None,
                 observed_outputs: List[str] = None, observed_outputs_observable: List[Observable] = None, **exec_info):

        super().__init__(sim_engine=sim_engine, model_filename=model_filename,
                         abs_tol=abs_tol, rel_tol=rel_tol, time_step=time_step,
                         observed_outputs=observed_outputs, observed_outputs_observable=observed_outputs_observable,
                         **exec_info)

        # observables in self.constraints represent control constraints
        # observables in self.fast_constraints represent control fast constraints (i.e., no requiring simulations)
        self.cached_ids: Set[str] = set()
        self.sbt_objective = sbt_objective
        # self.scenario_observables: Set[ScenarioObservable] = set()
        self.simulation_working_directory = exec_info["cwd"] # La directory in cui si trova il modello compilato e dove va scritto il file .mat della traiettoria da simulare
        self.set_input_generator(input_generator=input_generator, gen_input_filename=gen_input_filename)
        self.control_params = dict()

    def set_input_generator(self, input_generator: InputGenerator|None, gen_input_filename: str|None):
        self.input_generator = input_generator
        self.gen_input_full_filename = f"{self.simulation_working_directory}/{gen_input_filename}"

    def get_observables_ids(self) -> Set[str]:
        """Return the identifiers of the model observables, as a set of strings."""
        if not self.cached_ids:
            self.cached_ids: Set[str] = set()
            if self.objective:
                self.cached_ids.add(self.objective.id)

            for constraint in self.constraints:
                self.cached_ids.add(constraint.id)

            for fast_constraint in self.fast_constraints:
                self.cached_ids.add(fast_constraint.id)
        return self.cached_ids

    def get_scenario_kpi_goodness_threshold(self, obs_id: str) -> float:
        return [obs.goodness_threshold for obs in self.constraints if obs.id == obs_id][0]



    def get_normalized_params_values(self, parameters: Dict[str, float]) -> Dict[str, float]:
        normalized_params_values: Dict[str, float] = dict()
        for param_id, val in parameters.items():
            multiplier = self.parameters[param_id].multiplier
            offset = self.parameters[param_id].offset
            normalized_params_values[param_id] = val * multiplier + offset

        return normalized_params_values

    def set_control_parameters(self, control_params: Dict[str, float]):
        self.control_params = control_params

    def set_params(self, params_values: Dict[str, float]) -> None:
        if not self.control_params:
            raise RuntimeError('Control parameters must be setted before simulating the model')
        params_to_set: dict[str, float] = {pid: params_values[pid]
                                           for pid in params_values if not self.parameters[pid].to_input_generator}

        params_to_input_generator: dict[str, float] = {pid: params_values[pid]
                                           for pid in params_values if self.parameters[pid].to_input_generator}

        for param_id, value in params_to_set.items():
            param_obj = self.parameters[param_id]
            multiplier = param_obj.multiplier
            offset = param_obj.offset
            if param_obj.distribution == "uniform":
                if value < param_obj.lower_bound * multiplier + offset or \
                        value > param_obj.upper_bound * multiplier + offset:
                    raise ValueError(f"The value {value} for parameter {param_obj.name} is out of bounds.")
        params_to_set.update(self.control_params)

        params_to_set["fileName"] = f"\"{os.path.abspath(self.gen_input_full_filename)}\""
        self.instance.set_parameters(params_to_set)

        self.initial_values = self.build_initial_values()

        print(params_to_input_generator)
        print(self.gen_input_full_filename)
        self.input_generator.generate_to_file(params_to_input_generator, self.gen_input_full_filename)


