from apricopt.model.Observable import Observable
from apricopt.model.ObservableFunction import ObservableFunction
from pandas import DataFrame

from apricopt.IO.data_input import get_observable_formula

from typing import Callable, List, Set


class ScenarioObservable(Observable):
    def __init__(self, obs_id: str, name: str, expressions: List[str],
                 function: Callable = ObservableFunction.Identity,
                 lower_bound: float = float("-Inf"), upper_bound: float = float("Inf"),
                 goodness_threshold: float = float("Inf")):

        super(ScenarioObservable, self).__init__(obs_id, name, expressions, function, lower_bound, upper_bound)
        self.goodness_threshold = goodness_threshold


def get_scenario_constraints(constraints_df: DataFrame) -> Set[ScenarioObservable]:
    result: Set[Observable] = set()
    for obj_id, data in constraints_df.iterrows():
        func, expressions = get_observable_formula(data.observableFormula)
        result.add(ScenarioObservable(str(obj_id), data.observableName, expressions, function=func,
                                      goodness_threshold=data.goodnessThreshold))

    return result