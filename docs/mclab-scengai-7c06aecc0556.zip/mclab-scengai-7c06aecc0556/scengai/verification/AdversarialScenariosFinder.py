from oapackage import ParetoDoubleLong, doubleVector
from scengai.utils.ExecTimer import ExecTimer
import random

from typing import Dict, List


class AdversarialScenariosFinder:
    def __init__(self, random_seed: int, n_new: int, n_max: int = None):
        self.n_new = n_new
        self.n_max = n_max
        self.elem_idx = 0
        self.pareto_optimal_searcher = ParetoDoubleLong()
        self.all_counterexamples_penalty: List[Dict[str, float]] = []
        self.all_counterexamples_system_input: List[Dict[str, float]] = []
        self.scenarios_list_for_pareto: List[List[float]] = []
        self.n_pareto_optimal_points = 0
        self.n_dominated_points = 0
        self.timer = ExecTimer()
        self.cumulated_elapsed_time = 0
        self.rng_gen = random.Random(random_seed)

    def __is_adv_scenarios_found_with_reasoning(self):
        if self.n_max is not None:
            return not (self.n_new < 0 or self.n_max == self.n_new)
        return not self.n_new < 0

    def get_adversarial_scenarios(self):
        print("\n====== Collecting adversarial scenarios =====", flush=True)
        print(f"{len(self.all_counterexamples_system_input)} adversarial scenarios have been collected.", flush=True)
        self.timer.start()
        if self.__is_adv_scenarios_found_with_reasoning():
            adv_scenarios = self.get_found_adv_scenarios_with_complete_reasoning_policy()
        else:
            adv_scenarios = self.get_found_adv_scenarios_with_random_policy()

        self.cumulated_elapsed_time += self.timer.stop()
        return adv_scenarios

    def add_adversarial_scenario(self, adv_scenario_system_input: Dict[str, float], adv_scenario_penalty: Dict[str, float]):
        self.timer.start()
        if self.__is_adv_scenarios_found_with_reasoning():
            self.add_adv_scenario_with_reasoning_policy(adv_scenario_system_input, adv_scenario_penalty)
        else:
            self.add_adv_scenario_with_random_policy(adv_scenario_system_input)
        self.cumulated_elapsed_time += self.timer.stop()

    def add_adv_scenario_with_random_policy(self, scenario_penalty: Dict[str, float]):
        self.all_counterexamples_system_input.append(scenario_penalty)

    def add_adv_scenario_with_reasoning_policy(self, adv_scenario_system_input: Dict[str, float],
                                                adv_scenario_penalty: Dict[str, float]):

        scenario_list = [val[1] for val in (sorted(adv_scenario_penalty.items(), key=lambda i: i[0]))]
        self.scenarios_list_for_pareto.append(scenario_list)
        self.all_counterexamples_system_input.append(adv_scenario_system_input)
        elem = doubleVector(scenario_list)
        self.pareto_optimal_searcher.addvalue(elem, self.elem_idx)
        self.elem_idx += 1

    def get_total_number_of_adv_scenarios(self) -> int:
        return len(self.all_counterexamples_system_input)

    def __build_optimal_and_dominated_sets(self, indexes):
        optimal_pareto_points = []
        dominated_points = []
        for i in range(self.elem_idx):
            if i in indexes:
                optimal_pareto_points.append(self.all_counterexamples_system_input[i])
            else:
                dominated_points.append(self.all_counterexamples_system_input[i])

        return optimal_pareto_points, dominated_points

    def get_found_adv_scenarios_with_random_policy(self) -> List[Dict[str, float]]:
        print("A pareto random strategy has been selected", flush=True)
        return self.all_counterexamples_system_input

    def get_found_adv_scenarios_with_reasoning_policy(self):
        n_all_adv_scenarios = len(self.all_counterexamples_system_input)
        if n_all_adv_scenarios == 0:
            return []

        indexes = self.pareto_optimal_searcher.allindices()
        n_pareto_opt_points = len(indexes)

        self.__set_adversarial_scenarios_info(n_pareto_opt_points, n_all_adv_scenarios - n_pareto_opt_points)
        if n_pareto_opt_points > self.n_new:
            optimal_scenarios_idxs = self.rng_gen.sample(indexes, k=self.n_new)
            found_counterexample = [self.all_counterexamples_system_input[scenario_idx] for scenario_idx in optimal_scenarios_idxs]

        elif n_pareto_opt_points == self.n_new:
            found_counterexample = [self.all_counterexamples_system_input[scenario_idx] for scenario_idx in indexes]
        else:
            optimal_pareto_points, dominated_points = self.__build_optimal_and_dominated_sets(indexes)
            if len(dominated_points) <= self.n_new - n_pareto_opt_points:
                random_dominated_points = dominated_points
            else:
                random_dominated_points = self.rng_gen.sample(dominated_points, k=self.n_new - n_pareto_opt_points)
            found_counterexample = optimal_pareto_points + random_dominated_points

        return found_counterexample

    def get_found_adv_scenarios_with_complete_reasoning_policy(self):
        print("A pareto optimality-based strategy has been selected", flush=True)
        n_all_adv_scenarios = len(self.all_counterexamples_system_input)
        if n_all_adv_scenarios == 0:
            print("No adversarial scenarios has been collected", flush=True)
            return []

        if n_all_adv_scenarios <= self.n_new:
            print(f"{n_all_adv_scenarios} <= {self.n_new} adversarial scenarios has been collected.", flush=True)
            print("A random strategy is the facto used.", flush=True)
            return self.all_counterexamples_system_input

        indexes = self.pareto_optimal_searcher.allindices()
        n_pareto_opt_points = len(indexes)

        self.__set_adversarial_scenarios_info(n_pareto_opt_points, n_all_adv_scenarios - n_pareto_opt_points)
        if n_pareto_opt_points > self.n_new:
            print(f"pareto_opt_points={n_pareto_opt_points} > n_new={self.n_new} pareto "
                  f"optimal scenarios has been found.", flush=True)
            print(f"{self.n_new} pareto optimal scenarios will be selected at random.", flush=True)
            optimal_scenarios_idxs = self.rng_gen.sample(indexes, k=self.n_new)
            found_counterexample = [self.all_counterexamples_system_input[scenario_idx] for scenario_idx
                                    in optimal_scenarios_idxs]
            return found_counterexample

        if n_pareto_opt_points == self.n_new:
            print(f"pareto_opt_points={n_pareto_opt_points} = n_new={self.n_new} pareto optimal scenarios "
                  f"has been found.", flush=True)
            print(f"All found pareto optimal scenarios will be selected.", flush=True)
            found_counterexample = [self.all_counterexamples_system_input[scenario_idx] for scenario_idx in indexes]
            return found_counterexample

        print(f"pareto_opt_points={n_pareto_opt_points} < n_new={self.n_new} pareto optimal scenarios has been found.",
              flush=True)
        print("A group-based strategy selection of pareto optimal scenarios is used", flush=True)
        found_counterexample = []
        tmp_scenarios_list = list(self.all_counterexamples_system_input)
        group_cnt = 0
        while len(found_counterexample) < self.n_new:
            group_cnt += 1
            found_counterexample_to_add, new_tmp_scenarios_list, new_scenario_list_for_pareto = self.__get_pareto_optimal_points(
                indexes, tmp_scenarios_list,
                self.n_new - len(found_counterexample))

            print(f"\tGroup {group_cnt} = {len(indexes)} optimal scenarios - {len(tmp_scenarios_list) - len(indexes)} "
                  f"dominated scenarios -> {len(found_counterexample_to_add)} scenarios are selected.")

            found_counterexample += found_counterexample_to_add
            del tmp_scenarios_list, self.scenarios_list_for_pareto
            tmp_scenarios_list = new_tmp_scenarios_list
            self.scenarios_list_for_pareto = new_scenario_list_for_pareto

            n_curr_collected_scenarios = len(found_counterexample)
            if n_curr_collected_scenarios < self.n_new and len(self.scenarios_list_for_pareto) > self.n_new - len(
                    found_counterexample):
                self.pareto_optimal_searcher = ParetoDoubleLong()
                for idx in range(len(self.scenarios_list_for_pareto)):
                    elem = doubleVector(self.scenarios_list_for_pareto[idx])
                    self.pareto_optimal_searcher.addvalue(elem, idx)

                indexes = self.pareto_optimal_searcher.allindices()

            elif len(found_counterexample) < self.n_new:
                group_cnt += 1
                found_counterexample += tmp_scenarios_list
                print(f"Group {group_cnt} - All remaining {len(self.scenarios_list_for_pareto)}"
                      f" scenarios must be selected", flush=True)
                break

        return found_counterexample

    def __get_pareto_optimal_points(self, indexes, tmp_scenarios_list: list, remaining_scenarios_to_keep: int):
        pareto_opt_points = []
        new_tmp_scenario_list = []
        new_scenario_list_for_pareto = []
        for idx in indexes:
            pareto_opt_points.append(tmp_scenarios_list[idx])

        for idx in range(len(tmp_scenarios_list)):
            if idx not in indexes:
                new_tmp_scenario_list.append(tmp_scenarios_list[idx])
                new_scenario_list_for_pareto.append(self.scenarios_list_for_pareto[idx])

        return pareto_opt_points[:remaining_scenarios_to_keep], new_tmp_scenario_list, new_scenario_list_for_pareto

    def __set_adversarial_scenarios_info(self, n_pareto_optimal_points, n_dominated_points):
        self.n_pareto_optimal_points = n_pareto_optimal_points
        self.n_dominated_points = n_dominated_points

    def get_adversarial_scenarios_info(self):
        data = {'info': dict(), 'type': str(), 'elapsed_time': self.cumulated_elapsed_time,
                'total_adv_scenarios': len(self.all_counterexamples_system_input)}

        if self.__is_adv_scenarios_found_with_reasoning():
            data['type'] = 'pareto_optimal'
            data['info']['dominated'] = self.n_dominated_points
            data['info']['pareto_optimal'] = self.n_pareto_optimal_points
            data['info']['total'] = len(self.all_counterexamples_system_input)
        else:
            data['type'] = 'randomly'
            data['info']['total'] = len(self.all_counterexamples_system_input)

        return data

    def reset(self):
        self.elem_idx = 0
        self.pareto_optimal_searcher = ParetoDoubleLong()
        self.all_counterexamples_penalty = []
        self.all_counterexamples_system_input = []
        self.scenarios_list_for_pareto = []
        self.n_pareto_optimal_points = 0
        self.n_dominated_points = 0
        self.cumulated_elapsed_time = 0



