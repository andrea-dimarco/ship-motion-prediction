from scengai.verification.algorithm.SMCAlgorihm import SMCAlgorithm
from statsmodels.stats.proportion import proportion_confint

from math import ceil, log, pow
from typing import Dict


class SSFEOneStep(SMCAlgorithm):
    def __init__(self, epsilon: float, delta: float, delta_prime: float, n_max: int, n_new: int):
        super(SSFEOneStep, self).__init__(epsilon, delta,  n_max, n_new)
        self.delta_prime = delta_prime
        self.M = ceil((1 / (2*pow(epsilon, 2)))*log(2/delta))

        self.k = 0
        self.n_k = self.M
        self.a_k = 0
        self.b_k = 1
        self.m = 0

    def __determine_CI(self):
        a_k, b_k = proportion_confint(self.m, self.k, self.delta_prime, method='agresti_coull')
        return a_k, b_k

    def __h_a(self, gamma: float, epsilon: float) -> float:
        if gamma < 1 / 2:
            bound = 9/2 * pow(((3*gamma + epsilon)*(3*(1 - gamma) - epsilon)), -1)
        else:
            bound = 9/2 * pow(((3*(1 - gamma) + epsilon) * (3*gamma + epsilon)), -1)
        return bound

    def reset(self):
        super(SSFEOneStep, self).reset()
        self.k = 0
        self.n_k = self.M
        self.a_k = 0
        self.b_k = 1
        self.m = 0

    def one_step(self, scen_constraints: Dict[str, int], is_counterexample: bool = False) -> bool:
        z_w = 1 if is_counterexample else 0
        self.failed_scenarios_cnt += z_w
        return self.__algorithm_one_step(z_w)

    def __algorithm_one_step(self, z_w: int) -> bool:
        self.k += 1
        self.m += z_w
        a_k, b_k = self.__determine_CI()
        if a_k <= 1 / 2 <= b_k:
            self.n_k = self.M
        elif b_k < 1 / 2:
            self.n_k = ceil(
                (1 / (self.__h_a(b_k, self.epsilon) * pow(self.epsilon, 2))) * log(2 / (self.delta - self.delta_prime))
            )
        else:
            self.n_k = ceil(
                (1 / (self.__h_a(a_k, self.epsilon) * pow(self.epsilon, 2))) * log(2 / (self.delta - self.delta_prime))
            )

        self.n_k = min(self.n_k, self.M)
        return not self.k < self.n_k

    def get_probability_estimate(self) -> float:
        return self.m / self.k

    def get_number_of_samples(self) -> int:
        return self.k

    def get_maximum_number_of_samples(self):
        return self.M

    def is_early_stopping_reached(self) -> bool:
        return self.failed_scenarios_cnt == self.n_max

    def is_unbounded_policy(self) -> bool:
        return self.n_max < 0

    def is_verification_successful(self) -> bool:
        return self.failed_scenarios_cnt == 0

    def get_algorithm_info(self) -> dict:
        return {'estimate': self.m / self.k, 'samples': self.k,  'M': self.M, 'a_k': self.a_k, 'b_k': self.b_k}