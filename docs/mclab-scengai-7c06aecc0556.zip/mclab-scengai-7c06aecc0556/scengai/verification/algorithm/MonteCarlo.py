from scengai.verification.algorithm.SMCAlgorihm import SMCAlgorithm

from typing import Dict
from math import ceil, log


class MonteCarlo(SMCAlgorithm):
    def __init__(self, epsilon: float, delta: float, n_max: int, n_new: int):
        super(MonteCarlo, self).__init__(epsilon, delta, n_max, n_new)
        self.M = ceil(log(delta) / log(1 - epsilon))
        self.ht_cnt = 0

    def one_step(self, scen_constraints: Dict[str, int], is_counterexample: bool = False) -> bool:
        if is_counterexample: self.failed_scenarios_cnt += 1
        self.ht_cnt += 1
        return not self.ht_cnt < self.M

    def get_number_of_samples(self) -> int:
        return self.ht_cnt

    def get_maximum_number_of_samples(self) -> int:
        return self.M

    def is_early_stopping_reached(self) -> bool:
        return self.failed_scenarios_cnt == self.n_max

    def is_verification_successful(self) -> bool:
        return self.failed_scenarios_cnt == 0

    def is_unbounded_policy(self) -> bool:
        return self.n_max < 0

    def get_algorithm_info(self) -> dict:
        return {'M': self.M, 'samples': self.ht_cnt}

    def reset(self):
        super(MonteCarlo, self).reset()
        self.ht_cnt = 0
        self.failed_scenarios_cnt = 0
