from abc import ABC, abstractmethod
from typing import Dict


class SMCAlgorithm(ABC):
    def __init__(self, epsilon: float, delta: float, n_max: int, n_new: int):
        self.epsilon = epsilon
        self.delta = delta
        self.n_max = n_max
        self.n_new = n_new
        self.failed_scenarios_cnt = 0


    @abstractmethod
    def one_step(self, scen_constraints: Dict[str, int], is_counterexample: bool = False) -> bool:
        pass

    @abstractmethod
    def get_number_of_samples(self) -> int:
        pass

    @abstractmethod
    def get_maximum_number_of_samples(self) -> int:
        pass

    @abstractmethod
    def is_early_stopping_reached(self) -> bool:
        pass

    @abstractmethod
    def is_verification_successful(self) -> bool:
        pass

    @abstractmethod
    def is_unbounded_policy(self) -> bool:
        pass

    @abstractmethod
    def get_algorithm_info(self) -> dict:
        pass

    def reset(self):
        self.failed_scenarios_cnt = 0


