from scengai.model.SBTModel import SBTModel
from scengai.model.SynthesisModel import SynthesisModel
from scengai.simulation.SMCSimulatorPool import SMCSimulatorPool
from scengai.utils.StatsOnlineAlgorithms import StatsOnlineAlgorithms
from scengai.simulation.SimulatorPool import SimulatorPool
from scengai.verification.AdversarialScenariosFinder import AdversarialScenariosFinder
from scengai.verification.algorithm.SMCAlgorihm import SMCAlgorithm

import json, os
from multiprocessing import Queue

from typing import Union


class StatisticalModelChecker:
    simulator_pool: SMCSimulatorPool
    model : SynthesisModel|SBTModel
    task_request_queue: Queue
    task_response_queue: Queue

    def __init__(self, model: SynthesisModel | SBTModel, simulator_pool: SMCSimulatorPool,
                 task_request_queue: Queue, task_response_queue: Queue,
                 is_simulations_dump_policy: bool):
        self.log_observables = model.log_observables
        self.log_observables_values = {log_obs.id: {'min': float('Inf'), 'max': 0, 'avg': 0} for log_obs in
                                       self.log_observables}

        self.simulator_pool = simulator_pool
        self.task_request_queue = task_request_queue
        self.task_response_queue = task_response_queue
        self.is_simulations_dump_policy = is_simulations_dump_policy

        self.stats_online_algorithms = StatsOnlineAlgorithms()
        self.simulation_storage_for_dump = dict()
        self.index_sim_storage_for_dump = 0

        self.simulation_storage = dict()
        self.index_sim_storage = 0
        self.n_batch_calls = 0
        self.sample_cnt = 0

        self.smc_algorithm: Union[None, SMCAlgorithm] = None
        self.adv_scenarios_finder: Union[AdversarialScenariosFinder, None] = None

    def set_smc_algorithm(self, smc_algorithm: SMCAlgorithm, adv_scenarios_finder: AdversarialScenariosFinder):
        self.smc_algorithm = smc_algorithm
        self.adv_scenarios_finder = adv_scenarios_finder

    def check_smc_algorithm_for_verification(self):
        if self.smc_algorithm is None or self.adv_scenarios_finder is None:
            raise ValueError("SMC algorithm or scenario finder is not set")

    def reset(self):
        self.stats_online_algorithms.reset_algorithm()
        self.simulation_storage_for_dump = dict()
        self.index_sim_storage_for_dump = 0

        self.log_observables_values = {log_obs.id: {'min': float('Inf'), 'max': 0, 'avg': 0} for log_obs in
                                       self.log_observables}
        self.simulation_storage = dict()
        self.index_sim_storage = 0

        self.sample_cnt = 0
        self.n_batch_calls = 0

        self.adv_scenarios_finder.reset()
        self.smc_algorithm.reset()

    def __update_simulation_time_stats(self, sim_elapsed_time: float):
        self.stats_online_algorithms.increase_counter()
        self.stats_online_algorithms.update_sample_mean(sim_elapsed_time)
        self.stats_online_algorithms.update_sample_variance(sim_elapsed_time)

    def __store_simulations(self, scenario_constraints, sim_elapsed_time: float):
        self.simulation_storage_for_dump[self.index_sim_storage_for_dump] = dict()
        self.simulation_storage_for_dump[self.index_sim_storage_for_dump][
            'simulation_index'] = self.index_sim_storage_for_dump
        self.simulation_storage_for_dump[self.index_sim_storage_for_dump]['simulation_data'] = scenario_constraints
        self.simulation_storage_for_dump[self.index_sim_storage_for_dump]['simulation_time'] = sim_elapsed_time
        self.index_sim_storage_for_dump += 1

    def __get_next_sample(self, control_parameters):
        while True:
            if len(self.simulation_storage) == 0:
                self.index_sim_storage = 0
                self.n_batch_calls += 1
                self.simulator_pool.generate_scenarios_for_verification()
                self.task_request_queue.put((control_parameters, 'verification'))
                self.simulation_storage = self.task_response_queue.get(block=True)
                #self.simulation_storage = self.simulator_pool.simulate_scenarios(control_parameters, 'verification')

            (scenario_constraints, scenario, log_observables_data,
                      sim_elapsed_time) = self.simulation_storage.pop(self.index_sim_storage)
            self.index_sim_storage += 1

            if scenario[1]: continue

            # Storage scenarios data simulations
            if self.is_simulations_dump_policy: self.__store_simulations(scenario_constraints, sim_elapsed_time)

            self.sample_cnt += 1

            # Storage adversarial scenarios
            is_counterexample = False
            for scen_obs_id, scen_eval in scenario_constraints.items():
                if scen_eval > 0:
                    self.adv_scenarios_finder.add_adversarial_scenario(scenario, scenario_constraints)
                    is_counterexample = True
                    break

            return scenario_constraints, log_observables_data, sim_elapsed_time, is_counterexample

    def __update_log_observable_data(self, log_observables_data) -> None:
        for log_obs_id, val in log_observables_data.items():
            if val < self.log_observables_values[log_obs_id]['min']:
                self.log_observables_values[log_obs_id]['min'] = val

            if val > self.log_observables_values[log_obs_id]['max']:
                self.log_observables_values[log_obs_id]['max'] = val

            old_avg = self.log_observables_values[log_obs_id]['avg']
            self.log_observables_values[log_obs_id]['avg'] = old_avg + (val - old_avg) / self.sample_cnt

    def __check_verification_termination_condition(self, over: bool) -> bool:
        if self.smc_algorithm.is_unbounded_policy():
            return over

        return over or self.smc_algorithm.is_early_stopping_reached()

    def compute_verification(self, control_parameters):
        over = False
        over_loop = False
        while not over_loop:
            scen_constraints, log_observable_data, sim_elapsed_time, is_counterexample = self.__get_next_sample(control_parameters)
            over = self.smc_algorithm.one_step(scen_constraints, is_counterexample)
            over_loop = self.__check_verification_termination_condition(over)
            self.__update_log_observable_data(log_observable_data)
            self.__update_simulation_time_stats(sim_elapsed_time)

        algorithm_info = self.smc_algorithm.get_algorithm_info()
        verification_info = {'verification': {'samples': self.sample_cnt, 'batch_calls': self.n_batch_calls,
                                              'algorithm_info': algorithm_info}}
        self.simulator_pool.add_adversarial_scenarios(self.adv_scenarios_finder.get_adversarial_scenarios())
        verification_info['collecting_adv_scenarios'] = self.adv_scenarios_finder.get_adversarial_scenarios_info()
        verification_info['simulation_time_stats'] = dict()
        verification_info['simulation_time_stats']['avg_time'] = self.stats_online_algorithms.get_sample_mean()
        verification_info['simulation_time_stats']['variance'] = self.stats_online_algorithms.get_sample_variance()
        verification_info['termination'] = (over, self.smc_algorithm.is_early_stopping_reached())

        return verification_info, self.log_observables_values

    def dump_simulations(self, sim_output_path: str, algo_iteration: int):
        if not os.path.exists(sim_output_path):
            raise ValueError("A version of this JSON path must be exist")

        with open(sim_output_path, 'r') as f:
            data_to_store = json.load(f)

        verification_data_storage = data_to_store[f'algorithm_epoch_{algo_iteration}']['find_solution']
        verification_data_storage = dict(self.simulation_storage_for_dump, **verification_data_storage)
        data_to_store[f'algorithm_epoch_{algo_iteration}']['verification'] = verification_data_storage
        with open(sim_output_path, 'w') as f:
            json.dump(data_to_store, f, indent=4)

        del verification_data_storage, data_to_store, self.simulation_storage_for_dump
        self.simulation_storage_for_dump = dict()

    def close(self):
        pass