import json
import numpy as np
from typing import Dict, Tuple, Set, Any, List
import petab
from apricopt.IO.data_input import parse_config_file, get_objective, get_parameter_space, \
    get_constraints, get_fast_constraints, get_log_observables
from scengai.model.ScenarioObservable import get_scenario_constraints
from scengai.model.ScalableParameter import ScalableParameter, get_scalable_parameter_space
from apricopt.model.FastObservable import FastObservable
from apricopt.model.LogObservable import LogObservable
from apricopt.model.Observable import Observable
from apricopt.model.Parameter import Parameter
from apricopt.simulation.SimulationEngine import SimulationEngine
from apricopt.simulation.executable.Modelica.ModelicaExecutableEngine import ModelicaExecutableEngine
from apricopt.solving.blackbox.BlackBoxSolver import BlackBoxSolver
from apricopt.solving.blackbox.NOMAD.NOMADSolver import NOMADSolver
from scengai.blackbox.NOMADState import NOMADState
from scengai.model.SynthesisModel import SynthesisModel
from scengai.utils.cmd_utils import override_uncertain_parameters_config


def parse_control_optimization_config(config_filename: str, additional_data: dict = None, master_cwd: str = None) \
        -> Tuple[
            SynthesisModel,
            BlackBoxSolver, Dict[str, Any],
            Set[ScalableParameter],
            int, int, int, str, NOMADState, str, bool, str, List[str]
        ]:
    # Read the configuration YAML file
    data: dict = parse_config_file(config_filename)

    # Initialize the black-box optimizer class

    solver: BlackBoxSolver
    if data['solver'].lower() == "nomad":
        solver = NOMADSolver()
        nomad_state_folder = str(data['nomad_state_folder'])
        nomad_state = NOMADState()
    else:
        raise ValueError(f"Unknown black-box solver {data['solver']}")

    # Read 'files' section of the config file
    files = data['files']

    ########################################
    # Model simulation config data
    ########################################

    # If given, read the list of model quantities whose trajectory is returned after a simulation.
    if 'observed_outputs' in files:
        f = open(files['observed_outputs'])
        observed_outputs_text = f.read()
        f.close()
        synthesis_observed_outputs = json.loads(observed_outputs_text)
    else:
        synthesis_observed_outputs = None

    # Model object: it is responsible for storing the executable model and simulation config data, the objective, the control parameters ,
    # the constraints and the observed KPIs
    
    if data['simulator'] == 'ModelicaExecutable':
        sim_options = [
            '-noemit',
            '-lv=-stdout,-LOG_SUCCESS,-assert',
            '-noRestart',
            '-noEventEmit',
            #    '-noEquidistantTimeGrid',
            #            '-noRootFinding',
        ]

        sim_engine: SimulationEngine = ModelicaExecutableEngine(sim_options)
        #sim_engine: SimulationEngine = ModelicaExecutableEngineWithFiles()
    else:
        raise ValueError("This tool supports only the Modelica executable simulator.")


    executable_model = files['model']
    if not master_cwd:
        simulation_working_directory = data['simulation_working_directory'] \
            if data['simulation_working_directory'][-1] != '/' else data['simulation_working_directory'][:-1]
    else:
        simulation_working_directory = master_cwd

    model: SynthesisModel = SynthesisModel(sim_engine, executable_model,
                                           float('Inf'), float('Inf'), float('Inf'),
                                           observed_outputs=synthesis_observed_outputs,
                                           cwd=simulation_working_directory)

    # Create separate PEtab problems to distinguish different kinds of observables and read more than one parameter
    # table

    ########################################
    # Objective and optimization parameters
    ########################################
    # FIXME ME: @Leonardo se non funziona, dai come valore a sbml_file il path di un qualche file, magari l'xml
    objective_problem = petab.problem.Problem.from_files(sbml_file="",  # files['model'],
                                                         parameter_file=files['decision_variables'],
                                                         observable_files=files['objective'],
                                                         condition_file="")


    # Read the control parameter space, i.e. a set of Parameter object
    objective_problem.parameter_df = objective_problem.parameter_df.replace({np.nan: None})
    parameter_space: Set[ScalableParameter] = get_scalable_parameter_space(objective_problem.parameter_df)

    # Read the Observable object that observes the variable in the Modelica model used as objective for
    # the control optimization

    objective: Observable = get_objective(objective_problem.observable_df)

    # Read the initial control parameters from a PEtab condition table
    #initial_control_parameters: Dict[str, float] = [ctrl_params for ctrl_id, ctrl_params in
    #                                                get_conditions(objective_problem.condition_df).items()][0]

    ########################################################
    # Uncertain parameters for Statistical Model Checking
    ########################################################

    # Read the space of uncertain parameters from a PEtab Parameter table.

    # FIXME ME: @Leonardo se non funziona, dai come valore a sbml_file il path di un qualche file, magari l'xml
    uncertain_params_problem = petab.problem.Problem.from_files(sbml_file="",  # files['model'],  # ignored
                                                                parameter_file=files['uncertain_parameters'],
                                                                observable_files=files['objective']  # ignored
                                                                )

    uncertain_parameter_space: Set[ScalableParameter] = get_scalable_parameter_space(uncertain_params_problem.parameter_df)
    if "uncertain_parameters" in additional_data:
        override_uncertain_parameters_config(uncertain_parameter_space, additional_data['uncertain_parameters'])

    ########################################
    # Control constraints
    ########################################

    # Read the observable table that specifies which model variables/parameters implement control admissibility
    # constraints. For each candidate control parameter, before estimating the expected value of the objective in the
    # given space of uncertain parameters, the model is simulated and the value of these observed variables is used to
    # determine whether the control parameter is admissible.
    # A constraint is satisfied if the final value of the corresponding observed variable is lower or equal than zero
    # and violated if it is strictly greater than zero.

    if 'decision_constraints' in files:
        # FIXME ME: @Leonardo se non funziona, dai come valore a sbml_file il path di un qualche file, magari l'xml
        control_problem = petab.problem.Problem.from_files(sbml_file="",  # files['model'],
                                                           parameter_file=files['decision_variables'],
                                                           observable_files=files['decision_constraints'])
        control_constraints: Set[Observable] = get_constraints(control_problem.observable_df)
    else:
        control_constraints: Set[Observable] = set()

    ########################################
    # Fast Control constraints
    ########################################

    # Read the observable table that specifies constraints over control parameters assignments that can be evaluated
    # just on the control parameters, hence without requiring a model simulation to observe variable trajectories.
    # The semantics of each constraint is the same of that of "regular" control constraints
    # (<= 0: satisfied, > 0 violated).

    if 'decision_fast_constraints' in files:
        # FIXME ME: @Leonardo se non funziona, dai come valore a sbml_file il path di un qualche file, magari l'xml
        fast_constraints_problem = petab.problem.Problem.from_files(sbml_file="",  # files['model'],
                                                                    parameter_file=files['decision_variables'],
                                                                    observable_files=files['decision_fast_constraints'])
        control_fast_constraints: Set[FastObservable] = get_fast_constraints(fast_constraints_problem.observable_df)
    else:
        control_fast_constraints: Set[FastObservable] = set()

    if 'scenario_constraints' in files:
        # FIXME ME: @Leonardo se non funziona, dai come valore a sbml_file il path di un qualche file, magari l'xml
        scenario_constraints_problem = petab.problem.Problem.from_files(sbml_file="",  # files['model'],
                                                                    parameter_file=files['decision_variables'],
                                                                    observable_files=files['scenario_constraints'])
        scenario_constraints: Set[Observable] = get_scenario_constraints(scenario_constraints_problem.observable_df)
    else:
        scenario_constraints: Set[Observable] = set()


    ######################################################
    # Model additional params to be set for the simulation
    ######################################################

    if 'additional_system_parameters' in files:
        # FIXME ME: @Leonardo se non funziona, dai come valore a sbml_file il path di un qualche file, magari l'xml
        additional_parameters_problem = petab.problem.Problem.from_files(sbml_file="",  # files['model'],
                                                                    parameter_file=files['additional_system_parameters'],
                                                                    observable_files=files['objective'])
        additional_parameters: Set[Parameter] = get_parameter_space(additional_parameters_problem.parameter_df)
    else:
        additional_parameters: Set[Parameter] = set()




    ########################################
    # Model variables observed for logging
    ########################################

    # FIXME ME: @Leonardo se questa parte non ti serve o non hai ancora implementato il logging, commentala, la
    #  implementeremo in un secondo momento
    # If given, read the Observable table that specifies which model species/parameters will be observed and logged
    # during the optimization
    if 'log_observables' in files:
        # FIXME ME: @Leonardo se non funziona, dai come valore a sbml_file il path di un qualche file, magari l'xml
        log_observables_problem = petab.problem.Problem.from_files(sbml_file="",  # files['model'],
                                                                   parameter_file=files['decision_variables'],
                                                                   observable_files=files['log_observables'])
        log_observables: Set[LogObservable] = get_log_observables(log_observables_problem.observable_df)
    else:
        log_observables: Set[LogObservable] = set()

    #######################################################################################

    ############################################
    # Setting model parameters and observables
    ############################################

    model.set_parameter_space(parameter_space)
    model.objective = objective
    model.constraints = control_constraints
    model.fast_constraints = control_fast_constraints
    model.log_observables = log_observables
    model.scenario_observables = scenario_constraints
    model.additional_parameters = additional_parameters

    model.build_additional_params_values()

    ############################################
    # Read additional configuration parameters
    ############################################

    # Experiment timeout
    timeout = data['timeout']

    # Read solver parameters. Will be passed directly to the BlackBoxSolver object
    solver_parameters: Dict[str, Any] = {"solver_params": data['solver_parameters']}

    # Random seed, for reproducibility
    random_seed = int(data['random_seed'])

    # Number of parallel processes to use for control parameter evaluation.
    # As simulation is a computationally-intensive task, do not specify a number of processes
    # greater than the number of logical processor on your machine.

    num_processes = int(data['num_processes'])

    # Parameters for the AA algorithm (Dagum et al., 2000)

    # The epsilon and delta parameters
    # for the (eps, delta)-approximation of the expected value of the objective function.
    # Suggested values are eps, delta = 0.05

    ############################################
    # Output filename
    ############################################

    output_filename = data['output_filename']

    simulations_dump_policy = bool(data['simulations_dump'])
    simulations_dump_path = str(data['simulations_dump_filename'])

    return model, solver, solver_parameters, \
        uncertain_parameter_space, \
        num_processes, timeout, \
        random_seed, nomad_state_folder, nomad_state, \
        output_filename, simulations_dump_policy, simulations_dump_path, sim_options