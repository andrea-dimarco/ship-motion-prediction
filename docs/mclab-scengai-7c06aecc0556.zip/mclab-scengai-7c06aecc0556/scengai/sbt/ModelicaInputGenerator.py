from abc import abstractmethod
from os import times

from scengai.sbt.InputGenerator import InputGenerator

from scipy.io import savemat

import numpy as np


class ModelicaInputGenerator(InputGenerator):

    def generate(self, params: dict[str, float]) -> dict[str, list[tuple[float, float, ...]]]:
        # The returned dictionary must contain the key "time" and at least another key representing a variable name
        n_sig = []

        for el in params:
            if el.startswith("t") and el[1:-2] not in n_sig:
                n_sig.append(el[1:-2])

        signals = [{k: v for k, v in params.items() if k.startswith("t" + i) or k.startswith("v" + i) or k.startswith("o" + i)} for i in sorted(n_sig)]
        res = dict()
        for i, sig in enumerate(signals):
            items = sorted(sig.items(), key=lambda x: x[0])
            t = [val for k, val in  {k: v for k, v in items if k.startswith("t")}.items()]
            v = [val for k, val in {k: v for k, v in items if k.startswith("v")}.items()]
            o = [val for k, val in {k: v for k, v in items if k.startswith("o")}.items()]
            res["load" + str(i+1)] = [(tim, val) for tim, val in zip(t, v)]
        return res



    def generate_to_file(self, params: dict[str, float], filename: str) -> None:
        """
        table_names: dict[str, str] associa a ogni variabile del segnale il nome della tabella in cui deve essere scritta
        """
        """
        # t represents the time
        # v represents the value of the signal
        # o represents the oscillation of the signal
        #|
        #| params    -->     {"t1_1": x1_1, "v1_1": y1_1, "o1": z1,      ---------------
        #|                   "t1_2": x1_2, "v1_2": y1_2,                   FIRST SIGNAL
        #|                   ...                                                |
        #|                   "t1_n": x1_n, "v1_n": y1_n,                 _______|_______
        #|                   "t2_1": x2_1, "v2_1": y2_1, "o2": z2,       ---------------
        #|                   ...                                           SECOND SIGNAL
        #|                   "t2_n": x2_n, "v2_n": y2_n,                 _______|_______
        #|                   ...
        #|                   "tN_n": xN_n, "vN_n": yN_n, "oN": zN}
        #|
        #| filename  -->     "path/to/file.mat"
        #|
        #| table_names -->   {"load1" : "tab1",
        #|                      "load2" : "tab1",
        #|                      "load3" : "tab2",
        #|                       ...,
        #|                      "loadN" : "tabM"}
        """

        signals: dict[str, list[tuple[float, ...]]] = self.generate(params)
        print(signals)
        savemat(filename, signals)

    def generate_signals(self, params_list: list[dict[str, float]]) \
        -> list[dict[str, list[float]]]:
        return [self.generate(params) for params in params_list]

    def generate_uniform(self, n_signals: int = 1) -> list[dict[str, list[float]]]:
        raise NotImplementedError()

    def signal_variable_names(self) -> list[str]:
        # Returns the names of the variables in the signal
        raise NotImplementedError()


















#main
if __name__ == "__main__":
    # Example of usage
    params = {
        "t1_1": 0.0, "v1_1": 10.0, #"o1": 0.0,
        "t1_2": 1.0, "v1_2": 20.0,
        "t1_3": 2.0, "v1_3": 30.0,

        "t2_1": 0.0, "v2_1": 0.0, #"o2": 0.0,
        "t2_2": 1.0, "v2_2": 1.0,
        "t2_3": 2.0, "v2_3": 3.0,
        "t2_4": 3.0, "v2_4": 5.0,
        "t2_5": 4.0, "v2_5": 7.0,
        "t2_6": 5.0, "v2_6": 9.0,

        "t3_1": 0.0, "v3_1": 0.0, #"o3": 0.0,
        "t3_2": 3.0, "v3_2": 12,

        "t8_1": 0.0, "v8_1": 0.0,# "o8": 0.0,
        "t8_2": 1.0, "v8_2": 5.0,
        "t8_3": 2.0, "v8_3": 12.0,
        "t8_4": 3.0, "v8_4": 1.0,
        "t8_5": 4.0, "v8_5": 20.0,
        "t8_6": 5.0, "v8_6": 12.0,
    }

    generator = ModelicaInputGenerator()
    #print(params)
    signal = generator.generate(params)
    #print(signal)

    generator.generate_to_file(params, "test.mat")

    #signals = generator.generate_signals([params])
    #print(signals)