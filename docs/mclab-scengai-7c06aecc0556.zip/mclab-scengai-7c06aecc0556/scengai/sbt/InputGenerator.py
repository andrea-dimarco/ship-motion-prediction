from abc import ABC, abstractmethod


class InputGenerator(ABC):

    @abstractmethod
    def generate(self, params: dict[str, float]) -> dict[str, list[float]]:
        # given the parameter values, generates a signal
        # the returned dictionary must contain the key "time" and at least another key representing a variable name
        pass

    @abstractmethod
    def generate_signals(self, params_list: list[dict[str, float]]) \
        -> list[dict[str, list[float]]]:
        pass

    @abstractmethod
    def generate_to_file(self, params: dict[str, float], filename: str) -> None:
        pass

    @abstractmethod
    def generate_uniform(self, n_signals: int = 1) -> list[dict[str, list[float]]]:
        pass

