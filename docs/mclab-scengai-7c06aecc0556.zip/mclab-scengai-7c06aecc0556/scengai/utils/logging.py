from scengai.model.SynthesisModel import SynthesisModel
from apricopt.model.Parameter import Parameter

from typing import Set


def print_input_hyperparameters(algorithm_name: str, epsilon: float, delta: float, delta_prime: float,
                                num_processes: int, n_init: int, n_max: int, n_new: int, model: SynthesisModel,
                                additional_parameters: Set[Parameter], timeout: int):
    print(f"Selected algorithm for the verification: {algorithm_name}", flush=True)
    print("Input hyperparameters:", flush=True)
    print(f"\tNumber of workers: {num_processes}", flush=True)
    print("\tThreshoolds for feasibility:", flush=True)
    for scen_obs in model.scenario_observables:
        print(f"\t\t{scen_obs.id}: {scen_obs.goodness_threshold}", flush=True)
    print("\tHyperparameters for solution finding:", flush=True)
    print(f"\t\tInitial number of scenarios (n_init): {n_init}", flush=True)
    for param in additional_parameters:
        print(f"\t\t{param.id}: {param.nominal_value}", flush=True)

    print("\tHyperparameters for verification:", flush=True)
    print(f"\t\tEpsilon: {epsilon}", flush=True)
    print(f"\t\tDelta: {delta}", flush=True)

    if algorithm_name == 'SSFE':
        print(f"\t\tDelta Prime: {delta_prime}", flush=True)

    n_max_def = float("Inf") if n_max < 0 else n_max
    print(f"\t\tMaximum number of adversarial scenarios that can be collected during SMC (n_max): {n_max_def}",
             flush=True)

    n_new_def = float("Inf") if n_new < 0 else n_new
    print(f"\t\tThe number of adversarial scenarios to be collected for each epoch (n_new): {n_new_def}", flush=True)
    print("\tOther hyperparameters:", flush=True)
    print(f"\t\tTimeout: {timeout} sec", flush=True)


def print_warning_log(algorithm_name: str, ):
    if algorithm_name == 'MonteCarlo':
        print(f"Warning: the hyperparameter delta_prime is ignored for the MonteCarlo algorithm")


def print_verification_output_log(verification_info, log_observables_values, all_log_observables,
                                  n_adversarial_scenario: int, verification_batch: int,
                                  verification_elapsed_time: float, n_new: int, remaining_execution_time: int,
                                  timout: int) -> None:
    print("\n===== Certifying the proposed solution via Statistical Model Checking summary =====", flush=True)

    is_smc_completed, is_enough_adv_scenarios_obtained = verification_info['termination']
    if is_smc_completed:
        print("The Statistical Model Checking algorithm has been completed.", flush=True)
    else:
        print("Verification halt - Enough counterexamples (i.e., scenarios) as been found.", flush=True)

    print(f"\nThe maximum expected number of scenarios: {verification_info['verification']['algorithm_info']['M']}", flush=True)
    print(f"The number of scenarios used for the verification: {verification_info['verification']['samples']}",
          flush=True)
    print(f"The number of actual scenarios (i.e., simulations) produced: {verification_info['verification']['batch_calls']*verification_batch}", flush=True)
    print(f"Number of adversarial scenarios: {n_adversarial_scenario}", flush=True)

    true_n_new = n_new if n_new >= 0 else float("Inf")
    print(f"Summary on collecting {true_n_new} adversarial scenarios with highest penalty:", flush=True)
    if verification_info['collecting_adv_scenarios']['type'] == 'randomly':
        print(f"\tA randomness based strategy has been used to collect adversarial scenarios.", flush=True)
        print(f"\tThe overall number of collected adversarial scenarios is: {verification_info['collecting_adv_scenarios']['info']['total']}", flush=True)
    else:
        print("\tA pareto optimality-based strategy has been used to collect adversarial scenarios.", flush=True)
        print(f"\tThe overall number of collected adversarial scenarios is: {verification_info['collecting_adv_scenarios']['info']['total']}.", flush=True)

    print(f"\tElapsed time for collecting adversarial scenarios: {verification_info['collecting_adv_scenarios']['elapsed_time']:.6f} sec", flush=True)
    print(f"\nSimulation time statistics for Statistical Model Checking:", flush=True)
    print(f"\tAverage simulation time: {verification_info['simulation_time_stats']['avg_time']}", flush=True)
    print(f"\tVariance of average simulation time: {verification_info['simulation_time_stats']['variance']}",
          flush=True)

    print("\n[SMC LOG] Log Observables statistics:", flush=True)
    for log_observable in all_log_observables:
        print(f"[SMC LOG][MEAN]"
              f"\t{log_observable.format_message(log_observables_values[log_observable.id]['avg'])}",
              flush=True)
        print(f"[SMC LOG][MIN]"
              f"\t{log_observable.format_message(log_observables_values[log_observable.id]['min'])}", flush=True)
        print(f"[SMC LOG][MAX]"
              f"\t{log_observable.format_message(log_observables_values[log_observable.id]['max'])}", flush=True)

    print(f"\nVerification elapsed time: {verification_elapsed_time:.4f} sec", flush=True)
    if timout != -1: print(f"Remaining execution time: {remaining_execution_time} sec", flush=True)


