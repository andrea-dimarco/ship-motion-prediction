from scengai.verification.algorithm.MonteCarlo import MonteCarlo
from scengai.verification.algorithm.SSFEOneStep import SSFEOneStep
from scengai.verification.AdversarialScenariosFinder import AdversarialScenariosFinder

import os, json, time

from multiprocessing import Queue


def initialize_simulations_json_file(simulations_dump_path: str, algo_iteration: int):
    data_storage = {f'algorithm_epoch_{algo_iteration}': {'find_solution': {}, 'verification': {}}}
    if os.path.exists(simulations_dump_path) and algo_iteration == 0:
        os.unlink(simulations_dump_path)

    if not os.path.exists(simulations_dump_path):
        with open(simulations_dump_path, 'w') as f:
            json.dump(data_storage, f, indent=4)
    else:
        with open(simulations_dump_path, 'r') as f:
            loaded_saved_storage = json.load(f)

        data_storage = dict(loaded_saved_storage, **data_storage)
        with open(simulations_dump_path, 'w') as f:
            json.dump(data_storage, f, indent=4)


def check_algorithm_hyperparameters(n_max: int, n_new: int):
    if n_max < 0 or n_new < 0:
        return
    if n_new > n_max:
        raise ValueError(f"n_new={n_new} cannot be stricly greater than n_max={n_max}")


def alarm_function_for_timeout(signum, frame):
    raise Exception()


def store_current_output_from_solver(results_storage, results_from_bb, optimisation_result, algo_iteration: int,
                                     elapsed_time: float, n_scenarios: int, n_simulations: int):
    result_from_nomad = {"optimal_control_parameters": optimisation_result[0],
                         "optimal_objective": optimisation_result[1],
                         "best_unfeasible_objective": optimisation_result[2],
                         "optimization_bb_evals": optimisation_result[3],
                         "optimization_mads_iteration": optimisation_result[4]}

    results_storage[f'algorithm_epoch_{algo_iteration}']['finding_solution'] = {
        "result_from_bb": results_from_bb,
        "result_from_nomad": result_from_nomad,
        "optimization_elapsed_time": elapsed_time,
        "n_scenarios": n_scenarios,
        "n_simulations": n_simulations}


def store_current_result_from_verification(results_storage, verification_info, log_observables, algo_iteration: int,
                                           verification_elapsed_time: float, n_current_adversarial_scenarios: int,
                                           n_total_adversarial_scenarios: int, verification_batch: int):
    results_storage[f'algorithm_epoch_{algo_iteration}']['verification'] = {
        'verification_info': verification_info,
        'log_observables': log_observables,
        'verification_elapsed_time': verification_elapsed_time,
        'n_current_adversarial_scenarios': n_current_adversarial_scenarios,
        'n_total_adversarial_scenarios': n_total_adversarial_scenarios,
        'n_required_simulations': verification_info['verification']['algorithm_info']['M'],
        'n_used_simulations': verification_info['verification']['samples'],
        'n_actual_simulations': verification_info['verification']['batch_calls']*verification_batch,
    }


def build_smc_algorithm(algorithm_name: str, epsilon: float, delta: float, delta_prime: float, n_max: int, n_new: int,
                        random_seed: int):
    if algorithm_name == 'MonteCarlo':
        smc_algorithm = MonteCarlo(epsilon, delta, n_max, n_new)
        scenario_finder = AdversarialScenariosFinder(random_seed, n_new, n_max)
    elif algorithm_name == 'SSFE':
        smc_algorithm = SSFEOneStep(epsilon, delta, delta_prime, n_max, n_new)
        scenario_finder = AdversarialScenariosFinder(random_seed, n_new, n_max)
    else:
        raise ValueError("Wrong algorithm name is specfified")

    return smc_algorithm, scenario_finder


def deallocate_queues(task_request_queue: Queue, task_response_queue: Queue):
    while not task_request_queue.empty():
        task_request_queue.get()

    while not task_response_queue.empty():
        task_response_queue.get()

    task_request_queue.close()
    task_response_queue.close()


def wait_for_possibly_closure(simulator_pool_executor):
    if simulator_pool_executor.is_alive():
        time.sleep(0.1)
