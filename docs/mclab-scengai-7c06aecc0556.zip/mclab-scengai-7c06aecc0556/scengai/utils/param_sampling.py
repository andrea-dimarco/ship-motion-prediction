from scengai.model.ScalableParameter import ScalableParameter
from numpy.random import Generator
import numpy as np

from typing import List, Dict


def generate_n_uncertain_parameters(rng_genetator: Generator, params: Dict[str, ScalableParameter],
                                    n: int) -> List[Dict[str, float]]:
    result: List[Dict[str, float]] = []
    params_names = [param_id for param_id in params.keys()]
    params_names.sort()
    for _ in range(n):
        uncertain_item = generate_uncertain_parameters(rng_genetator, params)
        result.append(uncertain_item)
    return result


def generate_uncertain_parameters(rng_generator: Generator, params: Dict[str, ScalableParameter]) -> Dict[str, float]:
    result: Dict[str, float] = dict()
    params_names = [param_id for param_id in params.keys()]
    params_names.sort()
    for param_id in params_names:
        while True:
            if params[param_id].distribution == 'uniform' and params[param_id].granularity == 1:
                sample = rng_generator.integers(int(params[param_id].lower_bound), int(params[param_id].upper_bound) + 1)*params[param_id].multiplier
            elif params[param_id].distribution == 'uniform':
                #result[param_id] = params[param_id].lower_bound + (params[param_id].upper_bound -
                #                                                   params[param_id].lower_bound) * rng_generator.random()
                low = params[param_id].lower_bound / params[param_id].granularity
                hi = params[param_id].upper_bound / params[param_id].granularity
                sample = int(rng_generator.integers(int(low), int(hi), endpoint=True))*params[param_id].granularity
            elif params[param_id].distribution == 'normal':
                sample = rng_generator.normal(loc=params[param_id].mu, scale=params[param_id].sigma)
            else:
                raise ValueError(f"The sampling distribution {params[param_id].distribution} is not supported.")
            if params[param_id].lower_bound <=sample <= params[param_id].upper_bound:
                result[param_id] = sample
                break

    return result


def build_random_number_generator(seed: int) -> Generator:
    rng_gen = np.random.default_rng(seed)
    return rng_gen


