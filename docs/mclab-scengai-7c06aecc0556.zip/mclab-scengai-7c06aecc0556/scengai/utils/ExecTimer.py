import codetiming as ct


class ExecTimer:
    def __init__(self):
        self.timer = ct.Timer(logger=None)
        self.timer_is_started = False

    def start(self):
        if self.timer_is_started:
            self.timer.stop()

        self.timer.start()
        self.timer_is_started = True

    def stop(self):
        if not self.timer_is_started:
            return
        self.timer_is_started = False
        return self.timer.stop()
