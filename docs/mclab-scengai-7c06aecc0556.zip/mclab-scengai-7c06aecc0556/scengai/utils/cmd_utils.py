from scengai.model.SynthesisModel import SynthesisModel
from apricopt.model.Parameter import Parameter


from typing import List, Dict, NoReturn, Set


def parse_cmd_b_thresholds(goodness_threshold_cmd: List[str]) -> Dict[str, float]:
    data: Dict[str, float] = dict()
    for cmd_input in goodness_threshold_cmd:
        words = cmd_input.split("=")
        data[words[0]] = float(words[1])
    return data


def override_scenario_constraints_b_thresholds(model: SynthesisModel, goodness_thresholds: Dict[str, float]) -> NoReturn:
    for constraint in model.scenario_observables:
        if constraint.id in goodness_thresholds:
            constraint.goodness_threshold = goodness_thresholds[constraint.id]
            goodness_thresholds.pop(constraint.id)

    if len(goodness_thresholds) > 0:
        raise ValueError("Violation probabilities for wrong scenario constraints have been specified.")


def override_uncertain_parameters_config(uncertain_parameters: Set[Parameter], data: dict) -> NoReturn:
    for param in uncertain_parameters:
        if param.id in data:
            if "sigma" in data[param.id]:
                param.sigma = data[param.id]['sigma']