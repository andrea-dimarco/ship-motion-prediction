from math import sqrt

from typing import NoReturn


class StatsOnlineAlgorithms:
    def __init__(self):
        self.mean_k = 0
        self.mean_old_k = 0
        self.s = 0
        self.k = 0

    def increase_counter(self) -> NoReturn:
        self.k += 1

    def update_sample_mean(self, sample: float) -> NoReturn:
        self.mean_old_k = self.mean_k
        self.mean_k = self.mean_old_k + (sample - self.mean_old_k) / self.k

    def update_sample_variance(self, sample: float) -> NoReturn:
        self.s += (sample - self.mean_old_k)*(sample - self.mean_k)

    def get_sample_mean(self) -> float:
        return self.mean_k

    def get_sample_variance(self) -> float:
        return self.s / self.k

    def get_sample_std(self) -> float:
        return sqrt(self.s / self.k)

    def reset_algorithm(self) -> None:
        self.mean_k = 0
        self.mean_old_k = 0
        self.s = 0
        self.k = 0