from apricopt.model.Parameter import Parameter
from apricopt.solving.blackbox.BlackBoxSolver import BlackBoxSolver
from apricopt.simulation.executable.Modelica.ModelicaExecutableEngine import ModelicaExecutableEngine

from scengai.utils.logging import print_input_hyperparameters
from scengai.utils.cmd_utils import parse_cmd_b_thresholds, override_scenario_constraints_b_thresholds
from scengai.utils.utilities import store_current_output_from_solver, \
                                 initialize_simulations_json_file, wait_for_possibly_closure, deallocate_queues
from scengai.utils.ExecTimer import ExecTimer
from scengai.model.SynthesisModel import SynthesisModel
from scengai.input.input_nominal_system import parse_control_optimization_config
from scengai.blackbox.ModelicaSynthesisBlackBox import ModelicaSynthesisBlackBox
from scengai.blackbox.NOMADState import NOMADState
from scengai.blackbox.SolverExecutor import SolverExecutor
from scengai.simulation.SimulatorPoolExecutor import SimulatorPoolExecutor
from scengai.simulation.SimulatorPool import SimulatorPool


import os, json
from multiprocessing import Queue

from typing import List, Optional, Dict, Any, Collection, ClassVar


def run_nominal_system_design_from_config(config_filename: str,
                                          b_thresholds_cmd: List[str] = None,
                                          output_filename: str = None,
                                          master_cwd: str = None,
                                          worker_cwd: str = None,
                                          data_from_cmd: dict = None,
                                          simulations_dump_path_from_cmd: str = None,
                                          nomad_state_folder_from_cmd: str = None) -> None:

    model, solver, solver_parameters, \
        uncertain_parameter_space, \
        num_processes, timeout, \
        random_seed, nomad_state_folder_yaml, nomad_state, \
        output_filename_yaml, simulation_dump_policy, \
            simulations_dump_path_yaml, sim_options = parse_control_optimization_config(config_filename, data_from_cmd, master_cwd)

    output_pathname = output_filename if output_filename is not None else output_filename_yaml
    simulations_dump_path = simulations_dump_path_from_cmd if simulations_dump_path_from_cmd is not None else simulations_dump_path_yaml
    nomad_state_folder = nomad_state_folder_from_cmd if nomad_state_folder_from_cmd is not None else nomad_state_folder_yaml
    if b_thresholds_cmd is not None:
        b_threshold_data = parse_cmd_b_thresholds(b_thresholds_cmd)
        override_scenario_constraints_b_thresholds(model, b_threshold_data)

    print("\n\n=============== Control Parameters Synthesis via Randomized Algorithm ============", flush=True)
    print_input_hyperparameters("None", -1, -1, -1, num_processes, -1, -1, -1, model,
                                model.additional_parameters, timeout)

    run_nominal_system_design(model, ModelicaExecutableEngine, solver, solver_parameters, uncertain_parameter_space,
                              num_processes, timeout, random_seed, sim_options, output_pathname, nomad_state,
                              nomad_state_folder, simulation_dump_policy, simulations_dump_path, worker_cwd)


def run_nominal_system_design(synthesis_model: SynthesisModel,
                              sim_engine_class: ClassVar,
                              solver: BlackBoxSolver,
                              solver_parameters: Dict[str, Any],
                              uncertain_parameter_space: Collection[Parameter],
                              num_processes: int,
                              timeout: int,
                              random_seed: int,
                              sim_options,
                              output_filename: str,
                              nomad_state: NOMADState,
                              nomad_state_folder: str,
                              is_simulations_dump_policy: bool,
                              simulations_dump_path: str,
                              simulation_cwd: Optional[str] = None) -> None:

    opt_timer = ExecTimer()

    print("\n\n============ Control Parameters Synthesis ============", flush=True)

    # Initialize the black box that will be provided to the black-box optimization solver
    # The black box wraps the model and implements a multicore implementation to simulate the nominal scenario
    # needed to guide the search

    # Solver parameters to manage feasibility and NOMAD STATE
    state_cache_path = f'{nomad_state_folder}/state_cache.txt'
    solver_parameters['solver_params'].append("STOP_IF_FEASIBLE true")
    solver_parameters['solver_params'].append(f"CACHE_FILE {state_cache_path}")
    if timeout != -1:
        solver_parameters['solver_params'].append(f"MAX_TIME {timeout}")

    nomad_state.set_state_paths(state_cache_path)

    if os.path.exists(state_cache_path):
        os.remove(state_cache_path)

    uncertain_parameters_space_asdict: Dict[str, Parameter] = {
        param.id: param for param in uncertain_parameter_space
    }

    simulator_pool = SimulatorPool(num_processes, synthesis_model, sim_engine_class, random_seed, sim_options,
                                   uncertain_parameters_space_asdict, simulation_cwd)

    task_request_queue = Queue()
    task_response_queue = Queue()
    simulator_pool_executor = SimulatorPoolExecutor(simulator_pool, task_request_queue, task_response_queue)
    simulator_pool_executor.daemon = True
    simulator_pool_executor.start()

    black_box: ModelicaSynthesisBlackBox = ModelicaSynthesisBlackBox(ModelicaExecutableEngine,
                                                                     1, task_request_queue,
                                                                     task_response_queue,
                                                                     synthesis_model, is_simulations_dump_policy,
                                                                     simulation_cwd)

    # Set the initial control parameters as the starting point of the optimization
    black_box.set_optimization_parameters_initial_values_are_empty(True)

    # Scenarios configuration (fixed scenarios must be used)
    simulator_pool.set_number_of_scenarios(1)
    simulator_pool.generate_scenarios_to_find_solution()
    black_box.set_n_scenario_constraints(1)
    current_n_scenarios = 1

    # Initialisation for experiment timeout
    remaining_execution_time = None if timeout == -1 else timeout
    timeout_for_solution_is_reached = False

    # Storage for results
    results_storage = dict()
    results_storage[f'algorithm_epoch_{0}'] = dict()

    if is_simulations_dump_policy: initialize_simulations_json_file(simulations_dump_path, 0)

    # Solve the feasibility problem to find a solution with the scenario approach
    print(f"======== Find a solution with {current_n_scenarios} scenarios and black-box "
          f"optimisation ========", flush=True)
    additional_data = (is_simulations_dump_policy, simulations_dump_path, 0)
    opt_timer.start()
    opt_result, results_from_bb, \
        is_timeout_reached, n_performed_sim = SolverExecutor.find_solution(solver, black_box, solver_parameters,
                                                                           additional_data,remaining_execution_time)
    opt_elapsed_time = opt_timer.stop()

    print(f"\n\n====================\nSolution found in {opt_result[3]} black-box evaluations", flush=True)
    print(f"Number of performed simulations: {n_performed_sim}", flush=True)
    print(f"Feasibility elapsed time: {opt_elapsed_time:.4f} sec", flush=True)
    if timeout != -1: print(f"Remaining execution time: {remaining_execution_time} sec\n", flush=True)

    store_current_output_from_solver(results_storage, results_from_bb, opt_result, 0, opt_elapsed_time,
                                     simulator_pool.get_number_of_scenarios_for_optimization(),
                                     opt_result[3] * current_n_scenarios)

    if opt_result[2] > 0:
        print("No solution has been found by the solver", flush=True)
        timeout_for_solution_is_reached = True


    if is_timeout_reached:
        print("\nProcess timeout has been reached and the solver process has been killed.", flush=True)

    print(f"\nSystem design elapsed time: {opt_elapsed_time:.4f} sec\n", flush=True)

    if timeout_for_solution_is_reached:
        print("\nSolution has not been found for timeout.", flush=True)
        simulator_pool.terminate_pool_processes()
        task_request_queue.put('halt')
        wait_for_possibly_closure(simulator_pool_executor)
    else:
        simulator_pool.close_simulator_pool()
        task_request_queue.put('halt')
        simulator_pool_executor.join()

    deallocate_queues(task_request_queue, task_response_queue)
    if os.path.exists(state_cache_path):
        os.remove(state_cache_path)

    results_storage['algorithm_summary'] = {
        'elapsed_time': opt_elapsed_time,
        'iterations': 0,
    }

    with open(output_filename, "w") as out_f:
        json.dump(results_storage, out_f, indent=4)




