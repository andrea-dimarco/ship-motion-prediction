from scengai.model.ScalableParameter import ScalableParameter
from scengai.model.SynthesisModel import SynthesisModel
from scengai.sbt.InputGenerator import InputGenerator
from scengai.utils.ExecTimer import ExecTimer

from subprocess import CalledProcessError
from shutil import copytree, rmtree
import os

from typing import Optional, Dict, Tuple, List


class SUDSimulator:
    """
    This class models an instance of the SUD simulator.


    """

    def __init__(self, simulator_name: str, synthesis_model: SynthesisModel, sim_engine_class,
                 horizon: float, sim_options,
                 #uncertain_parameter_space: set[ScalableParameter],
                 input_generator: InputGenerator,
                 gen_input_filename: str,
                 worker_cwd: Optional[str] = None):
        """

        :param simulator_name:
        :param synthesis_model:
        :param sim_engine_class:
        :param horizon:
        :param sim_options:
        :param worker_cwd:
        """

        self.simulator_name = simulator_name
        main_model_cwd = synthesis_model.sim_engine.cwd
        self.process_cwd = f'{main_model_cwd}_{self.simulator_name}' if not worker_cwd else f'{worker_cwd}/model_{self.simulator_name}'
        if os.path.exists(self.process_cwd):
            rmtree(self.process_cwd)
        copytree(main_model_cwd, self.process_cwd)
        self.input_generator = input_generator
        self.gen_input_full_filename = f"{self.process_cwd}/{gen_input_filename}"

        self.simulator_sim_engine = sim_engine_class(sim_options)
        self.simulator_model = SynthesisModel(self.simulator_sim_engine, synthesis_model.model_filename,
                                              synthesis_model.absolute_tolerance,
                                              synthesis_model.relative_tolerance,
                                              synthesis_model.time_step,
                                              set(synthesis_model.uncertain_parameters.values()),
                                              self.input_generator,
                                              self.gen_input_full_filename,
                                              synthesis_model.observed_outputs,
                                              cwd=self.process_cwd)

        self.simulator_model.parameters = dict(synthesis_model.parameters)
        self.simulator_model.objective = synthesis_model.objective
        self.simulator_model.log_observables = synthesis_model.log_observables
        self.simulator_model.constraints = synthesis_model.constraints
        self.simulator_model.scenario_observables = synthesis_model.scenario_observables
        self.horizon = horizon

        self.additional_params_values = synthesis_model.get_additional_params_values()

        self.simulator_timer = ExecTimer()

    def simulate(self, control_parameters, scenario: Tuple[Dict[str, float], bool],
                 type_exp: str, additional_parameters_in=None) -> Tuple[Dict[str, float], Dict[str, float], float, bool]:

        stochastic_parameters, scenario_prev_failure = scenario
        if scenario_prev_failure and type_exp == 'design':
            return self.__scenario_failure_for_design()

        # Write value in txt file when it is a stochastic parameter
        stochastic_parameters_local = dict(stochastic_parameters)

        params_to_input_generator: dict[str, float] = {}
        for param_id, param_val in stochastic_parameters.items():
            if '.txt' in param_id:
                stochastic_parameters_local.pop(param_id)
                with open(f'{self.process_cwd}/{param_id}', 'w') as f:
                    f.write(f'{str(param_val)}\n')
            '''elif self.simulator_model.get_param(param_id).to_input_generator:
                params_to_input_generator[param_id] = param_val
        if params_to_input_generator:
            print(f"Params to input generator in SUDSimulator::simulate():  {params_to_input_generator}")
            print(self.gen_input_full_filename)
            self.input_generator.generate_to_file(params_to_input_generator, self.gen_input_full_filename)'''

        # Runtime selection of additional parameters
        if additional_parameters_in is not None:
            additional_parameters_local = dict(additional_parameters_in)
            additional_parameters_placeholder = additional_parameters_in
        else:
            additional_parameters_local = dict(self.additional_params_values)
            additional_parameters_placeholder = self.additional_params_values

        # Write value in txt file when it is an additional parameter
        for param_id, param_val in additional_parameters_placeholder.items():
            if '.txt' in param_id:
                additional_parameters_local.pop(param_id)
                with open(f'{self.process_cwd}/{param_id}', 'w') as f:
                    f.write(f'{str(param_val)}\n')


        # Set stochastic parameters
        self.simulator_model.set_fixed_params(stochastic_parameters_local)

        # Set control parameters
        self.simulator_model.set_params(control_parameters)

        # Set additional parameters for simulation
        self.simulator_model.set_fixed_params(additional_parameters_local)

        try:
            # Start tracing simulation time
            self.simulator_timer.start()

            # Simulate control with the assigned values for the uncertain parameters
            trajectory = self.simulator_sim_engine.simulate_trajectory(self.simulator_model, self.horizon)

            # Stop tracing simulation timer
            sim_elapsed_time = self.simulator_timer.stop()

            # Evaluate the scenario constraints
            scenario_goodness_trajectory: Dict[str, List[float]] = dict()
            scenario_constraints: Dict[str, float] = dict()
            # print("DEBUG IN SUDSimulator:128\n")

            for index, obs in enumerate(self.simulator_model.scenario_observables):
                scenario_goodness_trajectory[f'b_{obs.id}'] = [obs.goodness_threshold]
                obs_value_in_trajectory = obs.evaluate(trajectory)
                scenario_constraints[obs.id] = obs_value_in_trajectory - obs.goodness_threshold
                # print(f"\t{index}.{obs.id}: {obs_value_in_trajectory} - {obs.goodness_threshold} = {obs_value_in_trajectory - obs.goodness_threshold}")
            # print("END DEBUG IN SUDSimulator\n")

            # Objective value for NOMAD
            simulation_failure = False

            # Evaluate logging observables (control constraints have already been evaluated once)
            trajectory = dict(trajectory, **scenario_goodness_trajectory)
            log_observables_data: Dict[str, float] = {obs.id: obs.value(trajectory)
                                                      for obs in self.simulator_model.log_observables}

        except CalledProcessError as e:
            print(e)
            self.simulator_timer.stop()
            log_observables_data = dict()
            sim_elapsed_time = 0
            simulation_failure = True
            scenario_constraints: Dict[str, float] = {
                    obs.id: 0
                    for obs in self.simulator_model.scenario_observables}

        return scenario_constraints, log_observables_data, sim_elapsed_time, simulation_failure

    def __scenario_failure_for_design(self):
        scenario_constraints: Dict[str, float] = {
            obs.id: obs.lower_bound for obs in self.simulator_model.scenario_observables}
        return scenario_constraints, dict(), 0, True

    def update_scenario_observables(self, scenario_observables):
        self.simulator_model.scenario_observables = scenario_observables
