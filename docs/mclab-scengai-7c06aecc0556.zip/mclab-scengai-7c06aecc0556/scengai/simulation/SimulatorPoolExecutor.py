from threading import Thread
from multiprocessing import Queue

from scengai.simulation.SMCSimulatorPool import SMCSimulatorPool
from scengai.simulation.SimulatorPool import SimulatorPool


class SimulatorPoolExecutor(Thread):
    def __init__(self, simulator_pool: SimulatorPool|SMCSimulatorPool, task_request_queue: Queue, task_response_queue: Queue):
        super(SimulatorPoolExecutor, self).__init__()
        self.simulator_pool = simulator_pool
        self.task_request_queue = task_request_queue
        self.task_response_queue = task_response_queue

    def run(self) -> None:
        while True:
            next_task: tuple[dict, str] = self.task_request_queue.get(block=True)
            if isinstance(next_task, str):
                if next_task == 'halt':
                    return
                else:
                    raise ValueError("A wrong request has been received.")

            control_parameters, type_exec = next_task
            sim_results = self.simulator_pool.simulate_scenarios(control_parameters, type_exec)
            self.task_response_queue.put(sim_results)
