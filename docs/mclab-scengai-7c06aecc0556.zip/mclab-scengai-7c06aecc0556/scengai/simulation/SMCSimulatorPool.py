from multiprocessing.managers import DictProxy

from apricopt.simulation.SimulationEngine import SimulationEngine
from apricopt.simulation.executable.Modelica.ModelicaExecutableEngine import ModelicaExecutableEngine

from scengai.blackbox.ModelicaSBTBlackBox import ModelicaSBTBlackBox
from scengai.model.SBTModel import SBTModel
from scengai.model.ScalableParameter import ScalableParameter
from scengai.sbt.InputGenerator import InputGenerator
from scengai.simulation.SUDSimulator import SUDSimulator
from scengai.model.SynthesisModel import SynthesisModel
from scengai.utils.param_sampling import generate_n_uncertain_parameters, build_random_number_generator

from multiprocessing import Pool, Manager, current_process
from shutil import rmtree, copytree
from pathlib import Path
import os


from typing import Optional, Dict, List, Tuple, Type


#simulator: Union[SUDSimulator, None] = None
sbt_blackbox : ModelicaSBTBlackBox | None = None
thread_sbt_model: SBTModel | None = None
CHUNKSIZE = 1

def init_process(sbt_model: SBTModel, sim_engine_class: Type[ModelicaExecutableEngine],
                 input_generator: InputGenerator,
                 gen_input_filename: str,
                 sim_options,
                 # control_parameters: dict,
                 worker_cwd: str|None):
    global sbt_blackbox
    global thread_sbt_model


    main_model_cwd: str= sbt_model.sim_engine.cwd
    simulator_name = current_process().name
    process_cwd = f'{main_model_cwd}_{simulator_name}' if not worker_cwd else f'{worker_cwd}/model_{simulator_name}'
    if os.path.exists(process_cwd):
        rmtree(process_cwd)
    copytree(main_model_cwd, process_cwd)
    thread_gen_input_full_filename = f"{process_cwd}/{gen_input_filename}"





    thread_sbt_model = SBTModel(
        sim_engine=sim_engine_class(sim_options),model_filename=sbt_model.model_filename,
        abs_tol=sbt_model.absolute_tolerance, rel_tol=sbt_model.relative_tolerance,time_step=sbt_model.time_step,
        sbt_objective=sbt_model.sbt_objective,
        input_generator=input_generator, gen_input_filename=gen_input_filename,
        observed_outputs=sbt_model.observed_outputs, observed_outputs_observable=sbt_model.observed_outputs_observable,
        cwd=process_cwd
    )
    thread_sbt_model.parameters = dict(sbt_model.parameters)
    thread_sbt_model.objective = sbt_model.objective
    thread_sbt_model.log_observables = sbt_model.log_observables
    thread_sbt_model.constraints = sbt_model.constraints
    # cancella presto queste linee commentate, sono inutili
    # thread_sbt_model.scenario_observables = sbt_model.scenario_observables
    # thread_sbt_model.horizon = sbt_model.horizon

    # thread_sbt_model.additional_params_values = sbt_model.get_additional_params_values()





    # thread_sbt_model.set_control_parameters(control_parameters)
    # Creare la ModelicaSBTBlackBox (in ogni thread)
    sbt_blackbox = ModelicaSBTBlackBox(sim_engine_class, thread_sbt_model, worker_cwd)



def worker_simulate(control_parameters: dict, scenario: Tuple[Dict[str, float], bool], scenario_id: int,
                    results: DictProxy):


    thread_sbt_model.set_control_parameters(control_parameters)
    scenario_parameters, _ = scenario
    sim_elapsed_time = 0
    log_observables_data = {}
    try:

        evaluate_result: dict[str, float|set[str]] = sbt_blackbox.evaluate(scenario_parameters)
        sim_elapsed_time = evaluate_result['simulation_time']
        log_observables_data = evaluate_result['log_observables_data']
        positive_kpis_ids: set[str] = evaluate_result["positive_kpis_ids"]
        evaluate_results_only_violations_are_positive = dict() # *only* violations are positive (as it should be)
        # evaluate_results_only_violations_are_positive[sbt_blackbox.get_objective_id()] = evaluate_result[sbt_blackbox.get_objective_id()]
        for constraint_id in sbt_blackbox.get_progressive_barrier_constraints_ids():
            constraints_value: float = evaluate_result[constraint_id]
            if constraint_id not in positive_kpis_ids:
                # We flip back the sign to positive
                constraints_value = abs(constraints_value)
                evaluate_results_only_violations_are_positive[constraint_id] = constraints_value
        has_failed = False
    except Exception as e:
        evaluate_results_only_violations_are_positive = dict()
        has_failed = True
        raise e

    results[scenario_id] = (evaluate_results_only_violations_are_positive,
                            (scenario_parameters, has_failed),
                            log_observables_data,
                            sim_elapsed_time)




class SMCSimulatorPool:

    def __init__(self, num_processes: int, sbt_model: SBTModel, sim_engine_class,
                 random_seed: int, sim_options, #uncertain_parameter_space,
                 input_generator: InputGenerator, gen_input_filename: str,
                 worker_cwd: Optional[str] = None):

        self.pool = Pool(processes=num_processes, initializer=init_process,
                         initargs=(sbt_model, sim_engine_class, input_generator,
                                    gen_input_filename,sim_options,
                                   worker_cwd))

        # self.synthesis_model = synthesis_model
        self.sbt_model: SBTModel = sbt_model
        self.worker_cwd = worker_cwd
        self.n_scenarios = 0
        # self.initial_scenarios_for_optimisation: List[Dict[str, float]] = []
        # self.scenarios_for_optimisation: List[Dict[str, float]] = []
        self.scenarios_for_verification: List[Dict[str, float]] = []
        self.total_adversarial_scenarios: List[Dict[str, float]] = []
        self.current_adversarial_scenarios: List[Dict[str, float]] = []
        self.uncertain_parameter_space = self.sbt_model.parameters
        self.rng_generator = build_random_number_generator(random_seed)
        self.updated_scenario_observables = None
        self.batch_counter_design = 0
        self.batch_counter_verification = 0
        self.additional_parameters_values = None

    def simulate_scenarios(self, control_params, type_exp: str):
        manager = Manager()
        results = manager.dict()

        # (control_parameters: dict, scenario: Tuple[Dict[str, float], bool], scenario_id: int,
        #                     type_exp: str, results, updated_scenario_observables, additional_parameters)
        task_args = [(control_params, scenario, index, results)
                     for index, scenario in enumerate(self.scenarios_for_verification )]

        self.pool.starmap(worker_simulate, task_args, chunksize=CHUNKSIZE)
        return results

    def set_number_of_scenarios(self, n_scenarios: int):
        self.n_scenarios = n_scenarios

    def __generate_scenarios(self):
        sampled_scenarios = [(scenario_params, False) for scenario_params in
                             generate_n_uncertain_parameters(self.rng_generator,
                                                             self.uncertain_parameter_space, self.n_scenarios)]
        return sampled_scenarios

    def generate_scenarios_for_verification(self):
        self.scenarios_for_verification = self.__generate_scenarios()

    def get_number_of_current_adversarial_scenarios(self) -> int:
        return len(self.current_adversarial_scenarios)

    def get_number_of_total_adversarial_scenarios(self) -> int:
        return len(self.total_adversarial_scenarios)


    def clean_adversarial_scenarios(self) -> None:
        self.adversarial_scenarios = []

    def clean_current_adversarial_scenarios(self) -> None:
        self.current_adversarial_scenarios = []

    def add_adversarial_scenarios(self, adversarial_scenarios: List[Dict[str, float]]):
        self.total_adversarial_scenarios += adversarial_scenarios
        self.current_adversarial_scenarios += adversarial_scenarios

    def __remove_simulators_folder(self):
        if self.worker_cwd:
            cwd = self.worker_cwd
            for p in Path(cwd).glob(f"model_*"):
                for f in os.listdir(p):
                    os.unlink(f'{p}/{f}')
                rmtree(p, ignore_errors=True)
        else:
            cwd = self.sbt_model.sim_engine.cwd
            basename = Path(cwd).stem
            for p in Path(cwd).glob(f"../{basename}_*"):
                for f in os.listdir(p):
                    os.unlink(f'{p}/{f}')
                rmtree(p, ignore_errors=True)

    def close_simulator_pool(self):
        self.__remove_simulators_folder()
        self.pool.close()
        self.pool.join()

    def terminate_pool_processes(self, remove_folders=True):
        if remove_folders:
            self.__remove_simulators_folder()
        self.pool.terminate()
        self.pool.join()

    def update_scenario_observables(self, updated_scenario_observables):
        self.updated_scenario_observables = updated_scenario_observables

    def set_uncertain_parameter_space(self, uncertain_parameter_space):
        self.uncertain_parameter_space = uncertain_parameter_space

    def set_additional_parameters(self, additional_parameters):
        self.additional_parameters_values = {param.id: param.nominal_value for param in additional_parameters}
