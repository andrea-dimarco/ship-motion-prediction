from scengai.model.ScalableParameter import ScalableParameter
from scengai.sbt.InputGenerator import InputGenerator
from scengai.simulation.SUDSimulator import SUDSimulator
from scengai.model.SynthesisModel import SynthesisModel
from scengai.utils.param_sampling import generate_n_uncertain_parameters, build_random_number_generator

from multiprocessing import Pool, Manager, current_process
from shutil import rmtree
from pathlib import Path
import os


from typing import Union, Optional, Dict, List, Tuple


simulator: Union[SUDSimulator, None] = None

CHUNKSIZE = 1


def init_process(synthesis_model: SynthesisModel, sim_engine_class,
                 horizon: float, sim_options,
                 #uncertain_parameter_space: set[ScalableParameter],
                 input_generator: InputGenerator,
                 gen_input_filename: str,
                 worker_cwd: Optional[str] = None):
    global simulator
    simulator = SUDSimulator(current_process().name, synthesis_model, sim_engine_class, horizon, sim_options,
                             #uncertain_parameter_space,
                             input_generator, gen_input_filename,
                             worker_cwd)


def worker_simulate(control_params: Dict[str, float], scenario: Tuple[Dict[str, float], bool], scenario_id: int,
                    type_exp: str, results, updated_scenario_observables, additional_parameters):

    if updated_scenario_observables is not None:
        simulator.update_scenario_observables(updated_scenario_observables)

    (scenario_constraints, log_observables_data,
     sim_elapsed_time, simulation_failure) = simulator.simulate(control_params, scenario, type_exp,
                                                                additional_parameters_in=additional_parameters)

    results[scenario_id] = (scenario_constraints, (scenario[0], simulation_failure),
                            log_observables_data, sim_elapsed_time)


class SimulatorPool:

    def __init__(self, num_processes: int, synthesis_model: SynthesisModel, sim_engine_class,
                 random_seed: int, sim_options, #uncertain_parameter_space,
                 input_generator: InputGenerator, gen_input_filename: str,
                 worker_cwd: Optional[str] = None):

        self.pool = Pool(processes=num_processes, initializer=init_process,
                         initargs=(synthesis_model, sim_engine_class, 0, sim_options,
                                   #uncertain_parameter_space,
                                  input_generator, gen_input_filename,
                                   worker_cwd,))

        self.synthesis_model = synthesis_model
        self.worker_cwd = worker_cwd
        self.n_scenarios = 0
        self.initial_scenarios_for_optimisation: List[Dict[str, float]] = []
        self.scenarios_for_optimisation: List[Dict[str, float]] = []
        self.scenarios_for_verification: List[Dict[str, float]] = []
        self.total_adversarial_scenarios: List[Dict[str, float]] = []
        self.current_adversarial_scenarios: List[Dict[str, float]] = []
        self.uncertain_parameter_space = self.synthesis_model.uncertain_parameters #uncertain_parameter_space
        self.rng_generator = build_random_number_generator(random_seed)
        self.updated_scenario_observables = None
        self.batch_counter_design = 0
        self.batch_counter_verification = 0
        self.additional_parameters_values = None

    def simulate_scenarios(self, control_params, type_exp: str):
        manager = Manager()
        results = manager.dict()

        used_scenarios = self.scenarios_for_verification if type_exp == 'verification' else self.scenarios_for_optimisation
        task_args = [(control_params, scenario, index, type_exp, results, self.updated_scenario_observables,
                      self.additional_parameters_values) for index, scenario in enumerate(used_scenarios)]

        self.pool.starmap(worker_simulate, task_args, chunksize=CHUNKSIZE)

        return results

    def set_number_of_scenarios(self, n_scenarios: int):
        self.n_scenarios = n_scenarios

    def __generate_scenarios(self):
        sampled_scenarios = [(scenario_params, False) for scenario_params in
                             generate_n_uncertain_parameters(self.rng_generator,
                                                             self.uncertain_parameter_space, self.n_scenarios)]
        return sampled_scenarios

    def generate_scenarios_to_find_solution(self):
        sampled_scenarios = self.__generate_scenarios()
        self.initial_scenarios_for_optimisation += sampled_scenarios
        self.scenarios_for_optimisation += sampled_scenarios

    def generate_scenarios_for_verification(self):
        self.scenarios_for_verification = self.__generate_scenarios()

    def get_number_of_current_adversarial_scenarios(self) -> int:
        return len(self.current_adversarial_scenarios)

    def get_number_of_total_adversarial_scenarios(self) -> int:
        return len(self.total_adversarial_scenarios)

    def get_number_of_scenarios_for_optimization(self) -> int:
        return len(self.scenarios_for_optimisation)

    def clean_adversarial_scenarios(self) -> None:
        self.adversarial_scenarios = []

    def clean_current_adversarial_scenarios(self) -> None:
        self.current_adversarial_scenarios = []

    def build_scenarios_for_optimisation(self):
        self.scenarios_for_optimisation += self.current_adversarial_scenarios

    def add_adversarial_scenarios(self, adversarial_scenarios: List[Dict[str, float]]):
        self.total_adversarial_scenarios += adversarial_scenarios
        self.current_adversarial_scenarios += adversarial_scenarios

    def add_adversarial_scenarios_from_sbt(self, adversarial_scenarios: List[Dict[str, float]]):
        to_add = [(scenario, False) for scenario in adversarial_scenarios]
        # self.initial_scenarios_for_optimisation += to_add
        # self.scenarios_for_optimisation += to_add
        # self.total_adversarial_scenarios += to_add
        self.current_adversarial_scenarios += to_add    # questa deve esserci


    def __remove_simulators_folder(self):
        if self.worker_cwd:
            cwd = self.worker_cwd
            for p in Path(cwd).glob(f"model_*"):
                for f in os.listdir(p):
                    os.unlink(f'{p}/{f}')
                rmtree(p, ignore_errors=True)
        else:
            cwd = self.synthesis_model.sim_engine.cwd
            basename = Path(cwd).stem
            for p in Path(cwd).glob(f"../{basename}_*"):
                for f in os.listdir(p):
                    os.unlink(f'{p}/{f}')
                rmtree(p, ignore_errors=True)

    def close_simulator_pool(self):
        self.__remove_simulators_folder()
        self.pool.close()
        self.pool.join()

    def terminate_pool_processes(self, remove_folders=True):
        if remove_folders:
            self.__remove_simulators_folder()
        self.pool.terminate()
        self.pool.join()

    def update_scenario_observables(self, updated_scenario_observables):
        self.updated_scenario_observables = updated_scenario_observables

    def set_uncertain_parameter_space(self, uncertain_parameter_space):
        self.uncertain_parameter_space = uncertain_parameter_space

    def set_additional_parameters(self, additional_parameters):
        self.additional_parameters_values = {param.id: param.nominal_value for param in additional_parameters}





