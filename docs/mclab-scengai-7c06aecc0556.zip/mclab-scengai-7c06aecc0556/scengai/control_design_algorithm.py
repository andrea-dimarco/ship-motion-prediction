from apricopt.model.Parameter import Parameter
from apricopt.solving.blackbox.BlackBoxSolver import BlackBoxSolver
from apricopt.simulation.executable.Modelica.ModelicaExecutableEngine import ModelicaExecutableEngine
from apricopt.sampling.Sampler import sample_parameters

from scengai.blackbox.ModelicaSBTBlackBox import ModelicaSBTBlackBox
from scengai.model.SBTModel import SBTModel
from scengai.sbt.InputGenerator import InputGenerator
from scengai.utils.ExecTimer import ExecTimer
from scengai.utils.heuristic_cda_utils import k_score_violating_scenarios, choose_violating_scenarios
from scengai.utils.logging import print_input_hyperparameters, print_verification_output_log, print_warning_log
from scengai.utils.cmd_utils import parse_cmd_b_thresholds, override_scenario_constraints_b_thresholds
from scengai.utils.utilities import check_algorithm_hyperparameters, initialize_simulations_json_file, \
    store_current_output_from_solver, store_current_result_from_verification, \
    alarm_function_for_timeout, build_smc_algorithm, deallocate_queues, \
    wait_for_possibly_closure
from scengai.model.SynthesisModel import SynthesisModel
from scengai.blackbox.ModelicaSynthesisBlackBox import ModelicaSynthesisBlackBox
from scengai.simulation.SimulatorPool import SimulatorPool
from scengai.simulation.SMCSimulatorPool import SMCSimulatorPool
from scengai.simulation.SimulatorPoolExecutor import SimulatorPoolExecutor
from scengai.verification.StatisticalModelChecker import StatisticalModelChecker
from scengai.input.input import parse_control_optimization_config
from scengai.blackbox.SolverExecutor import SolverExecutor
from scengai.utils.param_sampling import generate_n_uncertain_parameters

import random
import numpy as np

from multiprocessing import Queue
import json, signal, math

from typing import List, Dict, Collection, Any, Type


def run_control_design_algorithm_from_config(config_filename: str,
                                             n_init_cmd: int = None,
                                             n_max_cmd: int = None,
                                             n_new_cmd: int = None,
                                             b_thresholds_cmd: List[str] = None,
                                             epsilon_cmd: float = None,
                                             delta_cmd: float = None,
                                             delta_prime_cmd: float = None,
                                             output_filename: str = None,
                                             master_cwd: str = None,
                                             worker_cwd: str = None,
                                             data_from_cmd: dict = None,
                                             n_processes_from_cmd: int = None,
                                             sbt_input_generator: InputGenerator=None,
                                             sbt_gen_input_filename:str=None,
                                             scenario_choice_heuristic_cmd: str = None) -> None:
    (model, sbt_model, \
     solver, control_solver_parameters, sbt_solver_parameters, \
     uncertain_parameter_space, \
     num_processes_yaml, timeout, algorithm_name,
     n_init_yaml, n_new_yaml, n_max_yaml,
     n_restarts_sbt, n_max_sbt, \
     epsilon_yaml, delta_yaml, \
     delta_prime_yaml, verification_batch, random_seed, \
     output_filename_yaml, simulation_dump_policy, simulations_dump_path_yaml, \
     sim_options, scenario_choice_heuristic_yaml) = parse_control_optimization_config(config_filename, data_from_cmd, master_cwd)



    output_pathname = output_filename if output_filename is not None else output_filename_yaml
    n_init = n_init_cmd if n_init_cmd is not None else n_init_yaml
    n_max = n_max_cmd if n_max_cmd is not None else n_max_yaml
    n_new = n_new_cmd if n_new_cmd is not None else n_new_yaml
    epsilon = epsilon_cmd if epsilon_cmd is not None else epsilon_yaml
    delta = delta_cmd if delta_cmd is not None else delta_yaml
    delta_prime = delta_prime_cmd if delta_prime_cmd is not None else delta_prime_yaml
    num_processes = n_processes_from_cmd if n_processes_from_cmd is not None else num_processes_yaml
    scenario_choice_heuristic_sbt = scenario_choice_heuristic_cmd if scenario_choice_heuristic_cmd is not None else scenario_choice_yaml
    if b_thresholds_cmd is not None:
        b_threshold_data = parse_cmd_b_thresholds(b_thresholds_cmd)
        override_scenario_constraints_b_thresholds(model, b_threshold_data)

    smc_algorithm, adv_scenario_finder = build_smc_algorithm(algorithm_name, epsilon, delta, delta_prime, n_max, n_new,
                                                             random_seed)
    print_warning_log(algorithm_name)
    check_algorithm_hyperparameters(n_max, n_new)

    print("\n\n=============== Control Parameters Synthesis via Design Algorithm ============", flush=True)
    print_input_hyperparameters(algorithm_name, epsilon, delta, delta_prime, num_processes, n_init, n_max, n_new, model,
                                model.additional_parameters, timeout, scenario_choice_heuristic_sbt)

    run_control_design_algorithm(model, ModelicaExecutableEngine, solver,
                                 control_solver_parameters, sbt_solver_parameters,
                                 uncertain_parameter_space,
                                 num_processes, timeout, smc_algorithm, adv_scenario_finder, n_init, n_new,
                                 verification_batch, random_seed, sim_options, output_pathname,
                                 scenario_search_enabled=True,
                                 sbt_model=sbt_model,
                                 sbt_input_generator=sbt_input_generator,
                                 sbt_gen_input_filename=sbt_gen_input_filename,
                                 n_restarts_sbt=n_restarts_sbt,
                                 n_max_sbt=n_max_sbt,
                                 scenario_choice_heuristic_sbt = scenario_choice_heuristic_sbt,
                                 worker_cwd=worker_cwd)


def run_control_design_algorithm(synthesis_model: SynthesisModel,
                                 sim_engine_class: Type,
                                 solver: BlackBoxSolver,
                                 control_solver_parameters: Dict[str, Any],
                                 sbt_solver_parameters: Dict[str, Any],
                                 uncertain_parameter_space: Collection[Parameter],
                                 num_processes: int,
                                 timeout: int,
                                 smc_algorithm,
                                 adv_scenario_finder,
                                 n_init: int,
                                 n_new: int,
                                 verification_batch: int,
                                 random_seed: int,
                                 sim_options,
                                 output_filename: str,
                                 simulation_cwd: str|None = None,
                                 scenario_search_enabled: bool = True,
                                 sbt_model: SBTModel|None = None,
                                 sbt_input_generator: InputGenerator|None=None,
                                 sbt_gen_input_filename: str|None = None,
                                 n_restarts_sbt=1,
                                 n_max_sbt=1,
                                 worker_cwd: str|None = None,
                                 scenario_choice_heuristic_sbt = 'k_random'
                                 ) -> None:

    if sbt_model:
        sbt_model.set_input_generator(sbt_input_generator, sbt_gen_input_filename)
        synthesis_model.set_input_generator(sbt_input_generator, sbt_gen_input_filename)
    total_violating_scenarios = 0
    algo_timer = ExecTimer()
    opt_timer = ExecTimer()
    verification_timer = ExecTimer()

    print("\n\n============ Control Parameters Synthesis ============", flush=True)

    # Initialize the black box that will be provided to the black-box optimization solver
    # The black box wraps the model and implements a multicore implementation to run independent simulations
    # needed to evaluate scenarios that guide the search

    # Solver parameters to manage feasibility and NOMAD STATE
    control_solver_parameters['solver_params'].append("STOP_IF_FEASIBLE true")
    sbt_solver_parameters['solver_params'].append("STOP_IF_FEASIBLE true")


    ''' 
        ============================================================
        Initialize simulator pool and executor for controller search
        ============================================================
    '''

    simulator_pool = SimulatorPool(num_processes=num_processes,
                                   synthesis_model=synthesis_model,
                                   sim_engine_class=sim_engine_class,
                                   random_seed=random_seed,
                                   sim_options=sim_options,
                                   #uncertain_parameters_space_asdict,
                                   input_generator=sbt_input_generator, gen_input_filename=sbt_gen_input_filename,
                                   worker_cwd=simulation_cwd)

    task_request_queue = Queue()
    task_response_queue = Queue()
    simulator_pool_executor = SimulatorPoolExecutor(simulator_pool, task_request_queue, task_response_queue)
    simulator_pool_executor.daemon = True
    simulator_pool_executor.start()

    black_box: ModelicaSynthesisBlackBox = ModelicaSynthesisBlackBox(ModelicaExecutableEngine,
                                                                     n_init, task_request_queue,
                                                                     task_response_queue,
                                                                     synthesis_model, False,
                                                                     simulation_cwd)

    # Set the initial control parameters as the starting point of the optimization
    black_box.set_optimization_parameters_initial_values_are_empty(True)

    ''' 
        =================================================================================================
        Initialize simulator pool, executor, and SMC algorithm for SMC verification of candidate controls
        =================================================================================================
    '''
    smc_task_request_queue: Queue = Queue()
    smc_task_response_queue: Queue = Queue()
    smc_simulator_pool: SMCSimulatorPool = SMCSimulatorPool(num_processes=num_processes,
                                                            sbt_model=sbt_model,
                                                            sim_engine_class=sim_engine_class,
                                                            random_seed=random_seed,
                                                            sim_options=sim_options,
                                                            input_generator=sbt_input_generator,
                                                            gen_input_filename=sbt_gen_input_filename,
                                                            worker_cwd=simulation_cwd)

    smc_simulator_pool_executor = SimulatorPoolExecutor(smc_simulator_pool,
                                                        smc_task_request_queue, smc_task_response_queue)
    smc_simulator_pool_executor.daemon = True
    smc_simulator_pool_executor.start()

    model_checker = StatisticalModelChecker(model=sbt_model,
                                            simulator_pool=smc_simulator_pool,
                                            task_request_queue=smc_task_request_queue,
                                            task_response_queue=smc_task_response_queue,
                                            is_simulations_dump_policy=False)

    model_checker.set_smc_algorithm(smc_algorithm, adv_scenario_finder)
    model_checker.check_smc_algorithm_for_verification()


    ''' 
        ==============================
        Start control design algorithm
        ==============================
    '''
    iter_cnt = 0
    over = False
    results_storage = dict()
    algo_timer.start()
    simulator_pool.set_number_of_scenarios(n_init)
    simulator_pool.generate_scenarios_to_find_solution()
    black_box.set_n_scenario_constraints(n_init)
    current_n_scenarios = n_init  # simulator_pool.get_number_of_scenarios_for_optimization()

    # Initialisation for experiment timeout
    remaining_execution_time = None if timeout == -1 else timeout
    timeout_for_solution_is_reached = False

    while not over:
        iter_cnt += 1
        results_storage[f'algorithm_epoch_{iter_cnt}'] = dict()
        print(f"\n========= Algorithm epoch {iter_cnt} ========= ", flush=True)
        print(f"======== Find a solution with {current_n_scenarios} scenarios and black-box "
              f"optimisation ========", flush=True)

        # Solve the feasibility problem to find a solution with the scenario approach
        additional_data = (False, "", 0) # to match type hint, to be removed

        opt_timer.start()
        control_opt_result, results_from_bb, \
            is_timeout_reached, n_performed_sim = SolverExecutor.find_solution(solver, black_box, control_solver_parameters,
                                                                               additional_data, remaining_execution_time)
        opt_elapsed_time = opt_timer.stop()
        remaining_execution_time = 0 if timeout == -1 else math.ceil(remaining_execution_time - opt_elapsed_time)

        if is_timeout_reached:
            print("\nProcess timeout has been reached and the solver process has been killed.", flush=True)
            timeout_for_solution_is_reached = True
            break

        print(f"\n\n====================\nSolution found in {control_opt_result[3]} black-box evaluations", flush=True)
        print(f"Number of performed simulations: {n_performed_sim}", flush=True)
        print(f"Feasibility elapsed time: {opt_elapsed_time:.4f} sec", flush=True)
        if timeout != -1: print(f"Remaining execution time: {remaining_execution_time} sec\n", flush=True)

        store_current_output_from_solver(results_storage, results_from_bb, control_opt_result, iter_cnt, opt_elapsed_time,
                                         simulator_pool.get_number_of_scenarios_for_optimization(),
                                         n_performed_sim)

        if control_opt_result[2] > 0:
            print("No solution has been found by the solver", flush=True)
            timeout_for_solution_is_reached = True
            break

        candidate_control: dict[str, float] = control_opt_result[0]
        print(f"Candidate control: {candidate_control}", flush=True)

        random.seed(random_seed)
        np.random.seed(random_seed)


        # Test and then verify the solution found by BBO

        verify: bool = True
        found_violating_scenarios = False

        # disabling SBT
        if scenario_search_enabled:
        #if False:
            # Search-based testing: test the candidate solution using BBO to
            #  look for violating scenarios before verifying with SMC
            print(f"======== Testing the obtained solution using Black-Box Optimization ========", flush=True)



            # set the controller to the one found by NOMAD in the feasibility run
            # sbt_model.set_fixed_params(candidate_control)
            sbt_model.set_control_parameters(candidate_control)
            sbt_black_box: ModelicaSBTBlackBox = ModelicaSBTBlackBox(
                sim_engine_class=ModelicaExecutableEngine,
                sbt_model=sbt_model,
                worker_cwd=simulation_cwd)

            # TODO decidere punti (scenario) iniziali per la search, uno per ogni restart da fare. Al momento sono scelti casualmente
            random_initial_scenarios = generate_n_uncertain_parameters(simulator_pool.rng_generator,
                                                                       sbt_model.parameters,
                                                                       n_restarts_sbt)



            # TODO ora prendiamo tutti gli scenari trovati nelle search, ma possiamo usare n_max_sbt per selezionare i peggiori
            violating_scenarios: list[dict[str, float]] = list()



            # TODO parallelizzare l'esecuzione delle SBTBlackBox
            # Inizialize the BBs with the random initial parameters
            sbt_black_boxes = [ModelicaSBTBlackBox(
                sim_engine_class=ModelicaExecutableEngine,
                sbt_model=sbt_model,
                worker_cwd=simulation_cwd) for _ in range(n_restarts_sbt)]

            # Set the optimization prameters initial values for the BBs
            for restart_i, bb in enumerate(sbt_black_boxes):
                bb.set_optimization_parameters_initial_values(random_initial_scenarios[restart_i])
            print("\n\n\nDEBUG PARALLEL:", sbt_black_boxes)
            restarts_cache = SolverExecutor.find_solutions(solver,
                                          sbt_black_boxes,
                                          sbt_solver_parameters,
                                          additional_data,
                                          remaining_execution_time)


            sbt_opt_results: list(float) = []
            sbt_black_boxes_cache = dict()

            for restart in restarts_cache:
                sbt_opt_results.append(restart[0][1])
                sbt_black_boxes_cache.update(restart[4])

            if min(sbt_opt_results) < 0:
                best_violating_scenarios = choose_violating_scenarios(sbt_black_boxes_cache, n_max_sbt, scenario_choice_heuristic_sbt)
                found_violating_scenarios = True
                print("\nDEBUG: Founded ", len(best_violating_scenarios), " violating scenarios", flush=True)
                print("BEST VIOLATING SCENARIOS:", best_violating_scenarios, flush=True)
                simulator_pool.add_adversarial_scenarios_from_sbt(best_violating_scenarios)


        # <-- --- ---  SMC  --- --- -->
        if not found_violating_scenarios:
            print(f"======== Verifying the obtained solution using Statistical Model Checking ========", flush=True)
            smc_simulator_pool.set_number_of_scenarios(verification_batch)
            signal.signal(signal.SIGALRM, alarm_function_for_timeout)
            signal.alarm(remaining_execution_time)

            verification_timer.start()
            try:
                verification_info, log_observables_values = model_checker.compute_verification(candidate_control)
                signal.alarm(0)
            except Exception as e:
                print("\nThe verification procedure may have reached the timeout.", flush=True)
                timeout_for_solution_is_reached = True
                break

            verification_elapsed_time = verification_timer.stop()
            remaining_execution_time = None if timeout == -1 else math.ceil(remaining_execution_time - verification_elapsed_time)

            store_current_result_from_verification(results_storage, verification_info, log_observables_values, iter_cnt,
                                                   verification_elapsed_time,
                                                   smc_simulator_pool.get_number_of_current_adversarial_scenarios(),
                                                   smc_simulator_pool.get_number_of_total_adversarial_scenarios(),
                                                   verification_batch)
            print_verification_output_log(verification_info, log_observables_values, sbt_model.log_observables,
                                          smc_simulator_pool.get_number_of_current_adversarial_scenarios(), verification_batch,
                                          verification_elapsed_time, n_new, remaining_execution_time, timeout)

            simulator_pool.add_adversarial_scenarios(smc_simulator_pool.current_adversarial_scenarios)

            # Continue with next epoch if violating scenarios were found by either Search-based testing or SMC
            over = len(smc_simulator_pool.current_adversarial_scenarios) == 0
            smc_simulator_pool.clean_current_adversarial_scenarios()
            smc_simulator_pool.clean_adversarial_scenarios()

        # Continue with next epoch if violating scenarios were found by either Search-based testing or SMC
        # over = True if smc_simulator_pool.get_number_of_current_adversarial_scenarios() == 0 else False

        if not over:
            simulator_pool.build_scenarios_for_optimisation()
            simulator_pool.clean_current_adversarial_scenarios() # probabilmente questo non ha più effetto
            current_n_scenarios = simulator_pool.get_number_of_scenarios_for_optimization()
            simulator_pool.set_number_of_scenarios(current_n_scenarios)
            black_box.set_n_scenario_constraints(current_n_scenarios)
            black_box.reset()

            # Settiamo il controllore iniziale a quello trovato nell'ultima search
            # Deve soddisfare tutti i vincoli su tutti gli scenari noti finora
            black_box.set_optimization_parameters_initial_values_are_empty(False)
            black_box.set_optimization_parameters_initial_values(candidate_control)

            control_solver_parameters = {'solver_params': [param for param in
                                                           control_solver_parameters['solver_params'] if
                                                           "LH_SEARCH" not in param]}

            model_checker.reset()




    all_algo_elapsed_time = algo_timer.stop()
    print(f"\nRandomised smc execution elapsed time: {all_algo_elapsed_time:.4f} sec\n", flush=True)

    if timeout_for_solution_is_reached:
        print("\nSolution has not been found for timeout.", flush=True)
        simulator_pool.terminate_pool_processes()
        smc_simulator_pool.terminate_pool_processes()
        task_request_queue.put('halt')
        smc_task_request_queue.put('halt')
        wait_for_possibly_closure(simulator_pool_executor)
        wait_for_possibly_closure(smc_simulator_pool_executor)
    else:
        simulator_pool.close_simulator_pool()
        smc_simulator_pool.close_simulator_pool()
        task_request_queue.put('halt')
        smc_task_request_queue.put('halt')


    simulator_pool_executor.join()
    smc_simulator_pool_executor.join()

    deallocate_queues(task_request_queue, task_response_queue)
    deallocate_queues(smc_task_request_queue, smc_task_response_queue)


    results_storage['algorithm_summary'] = {
        'elapsed_time': all_algo_elapsed_time,
        'iterations': iter_cnt,
    }

    with open(output_filename, "w") as out_f:
        json.dump(results_storage, out_f, indent=4)



