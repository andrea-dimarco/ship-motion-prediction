import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="scengai",
    version="0.0.1",
    author="Leonardo Picchiami",
    author_email="picchiami@di.uniroma1.it",
    description="A python library for the computation of robust control design for industrial control systems",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://raise.uniroma1.it",
    packages=setuptools.find_packages(),
    install_requires=[
        'apricopt==0.0.2a3dev21',
        'codetiming',
        'colorama',
        'jsonschema',
        'pandas',
        'petab',
        'Pillow',
        'pyparsing',
        'pyrsistent',
        'python-dateutil',
        'pytz',
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Operating System :: OS Independent",
    ],
    
    python_requires='>=3.6',
)
